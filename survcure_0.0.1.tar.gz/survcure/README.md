
<!-- README.md is generated from README.Rmd. Please edit that file -->

# survcure

Implementation of the unified family of cure rate models

## Installation

<!-- You can install the released version of survcure from [CRAN](https://CRAN.R-project.org) with: -->
<!-- ``` r -->
<!-- install.packages("survcure") -->
<!-- ``` -->

And the development version from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("fndemarqui/survcure")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(tidyverse)
library(survcure)

data(e1673)

e1673 <- e1673 %>%
  mutate(
    age = scale(age),
  )

n <- nrow(e1673)
m <- ceiling(n^0.4)

fit1 <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = bp("ph"), incidence = bell("log"),
                 data = e1673, init=0)
summary(fit1)
#> Call:
#> survcure(formula = Surv(time, status) ~ age + gender + ps | age + 
#>     gender + ps, data = e1673, incidence = bell("log"), latency = bp("ph"), 
#>     init = 0)
#> 
#> Cure fraction coefficients:
#>              Estimate    StdErr z.value   p.value    
#> (Intercept)  0.594373  0.116206  5.1148 3.140e-07 ***
#> age          0.406566  0.089718  4.5316 5.854e-06 ***
#> gender      -0.437786  0.153067 -2.8601  0.004235 ** 
#> ps          -0.036916  0.220771 -0.1672  0.867203    
#> ---
#> Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#> 
#> Promotion times coefficients:
#>          Estimate     StdErr z.value   p.value    
#> age    -0.3976971  0.1059467 -3.7537 0.0001742 ***
#> gender -0.0039877  0.1974729 -0.0202 0.9838890    
#> ps      0.7198878  0.2742067  2.6253 0.0086561 ** 
#> ---
#> Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#> 
#> --- 
#> loglik = -1314.525   AIC = 2671.049 
#> Algorithm convergence: TRUE

fit2 <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = pe("po"), incidence = poisson("log"),
                 data = e1673, init=0)
summary(fit2)
#> Call:
#> survcure(formula = Surv(time, status) ~ age + gender + ps | age + 
#>     gender + ps, data = e1673, incidence = poisson("log"), latency = pe("po"), 
#>     init = 0)
#> 
#> Cure fraction coefficients:
#>             Estimate   StdErr z.value   p.value    
#> (Intercept)  0.46684  0.28134  1.6593 0.0970496 .  
#> age          0.39467  0.11458  3.4445 0.0005721 ***
#> gender      -0.34457  0.15535 -2.2180 0.0265563 *  
#> ps          -0.11759  0.26397 -0.4455 0.6559919    
#> ---
#> Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#> 
#> Promotion times coefficients:
#>         Estimate    StdErr z.value   p.value    
#> age    -0.439893  0.129866 -3.3873 0.0007059 ***
#> gender -0.094617  0.262050 -0.3611 0.7180519    
#> ps      0.864581  0.374188  2.3106 0.0208577 *  
#> ---
#> Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#> 
#> --- 
#> loglik = -1312.059   AIC = 2666.117 
#> Algorithm convergence: TRUE
```
