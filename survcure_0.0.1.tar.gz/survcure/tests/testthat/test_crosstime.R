


library(survcure)
library(tidyverse)
library(GGally)

set.seed(1234567890)
beta <- c(0.5, -0.2, -0.1)
gamma <- c(0.9, 1);
psi = 2
phi = -1
n <- 1000

# generating the set of explanatory variables:
covariates <- data.frame(
  trt = rbinom(n, 1, 0.5),
  age = rnorm(n)
)

# generating the data set:
data <- rsurvcure(
  ~ trt + age|trt, covariates = covariates,
  incidence = "bell",
  latency = "weibull",
  gamma = gamma,
  beta = beta,
  psi = psi,
  phi = phi,
  max_fu = 5
)

glimpse(data)

m <- ceiling(sqrt(n))
m <- 5
fit <- survcure(Surv(time, status) ~ trt + age|trt, data = data,
                incidence = "poisson", latency = weibull("yp"), init = 0, m = m)
summary(fit)

newdata <- data.frame(
  trt = c(0, 1),
  age = c(0, 0)
)
ekm <- survfit(Surv(time, status)~trt, data = data)
surv <- survfit(fit, newdata = newdata)

surv <- data.frame(time = surv$time, surv1 = surv$surv[[1]], surv2 = surv$surv[[2]]) %>%
  pivot_longer(cols = 2:3, names_to = "trt", values_to = "surv")


newdata1 <- data.frame(
  trt = 0,
  age = 0
)

newdata2 <- data.frame(
  trt = 1,
  age = 0
)


tcross <- cross_time(fit, newdata1, newdata2, nboot = 100)
tcross
ggsurv(ekm) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt)) +
  geom_vline(xintercept = tcross$`Est.`, color = "blue") +
  geom_vline(xintercept = tcross$`2.5%`, color = "blue", linetype = "dashed") +
  geom_vline(xintercept = tcross$`97.5%`, color = "blue", linetype = "dashed") +
  ylim(0, 1)




ggsurv(ekm) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt)) +
  geom_vline(data = tcross, aes(xintercept = time), color = "blue") +
  geom_vline(data = tcross, aes(xintercept = `2.5%`), color = "blue", linetype = "dashed") +
  geom_vline(data = tcross, aes(xintercept = `97.5%`), color = "blue", linetype = "dashed") +
  ylim(0, 1)


ggsurv(ekm) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt)) +
  geom_vline(data = tcross, aes(xintercept = time), color = "blue") +
  geom_vline(data = tcross, aes(xintercept = lwr), color = "blue", linetype = "dashed") +
  geom_vline(data = tcross, aes(xintercept = upr), color = "blue", linetype = "dashed") +
  ylim(0, 1)




ggsurv(ekm) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt)) +
  geom_vline(data = tcross, aes(xintercept = time), color = "blue") +
  geom_ribbon(data = tcross, aes(xmin = lwr, xmax = upr, group = surv$trt), alpha = 0.1) +
  ylim(0, 1)



ggsurv(ekm) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt)) +
  geom_vline(data = tcross, aes(xintercept = time), color = "blue") +
  geom_area(data = tcross, aes(x = lwr, y = upr, group = 1), orientation = "y") +
  ylim(0, 1)


