library(testthat)
library(survcure)

test_check("survcure")
