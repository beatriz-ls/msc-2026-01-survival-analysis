library(GGally)

n <- 2000
trt <- rbinom(n, 1, 0.5)

X1 <- cbind(1, trt)
X2 <- matrix(trt, ncol = 1)
beta <- c(0.5, -0.2)
psi <- 1
phi <- -0.5
gamma <- c(1.5, 1)
gamma <- c(0.9, 1); phi = -1; psi = 2   # usar esse!!!!
# gamma <- c(0.8, 1); phi = -1; psi = 1

mu0 <- exp(beta[1])
mu1 <- exp(sum(beta))
exp(-mu0)
exp(-mu1)


baseline <- "weibull"
family <- "poisson"
nu <- 1

# time <- seq(0.001, 4, length.out = 1000)
# X1 <- unique(matrix(c(1, 1, 0, 1), ncol = 2))
# X2 <- X1[, 2, drop = FALSE]
# lambda <- as.numeric(exp(X2%*%psi))
# kappa <- as.numeric(exp(X2%*%phi))
# mu <- as.numeric(exp(X1%*%beta))
# Ht0 <- gamma[2]*(time^gamma[1])
# Rt0 <- exp(Ht0) - 1
# Sz0 <- (1+lambda[1]*Rt0/kappa[1])^(-kappa[1])
# Sz1 <- (1+lambda[2]*Rt0/kappa[2])^(-kappa[2])
# St0 <- exp(-mu[1]*(1-Sz0))
# St1 <- exp(-mu[2]*(1-Sz1))
#
# plot(time, St0, type = "l", ylim = c(0,1))
# lines(time, St1, col = "red")
# lines(time, rep(exp(-mu0), n), lty = 2)
# lines(time, rep(exp(-mu1), n), lty = 2, col = 2)




teste <- rsurvcure(family = "poisson",
                   baseline = "weibull",
                   X1 = X1, X2 = X2, beta = beta,
                   psi = psi, phi = phi, gamma = gamma,
                   nu = NULL, max_fu = 5)


dados <- as.data.frame(cbind(teste, trt = trt))
apply(dados, 2, mean)

yp <- survcure(Surv(time, status) ~ trt|trt,
               family = "poisson",
               baseline = pe("yp"),
               data = dados,
               init = 0, m = 10)
#
# ph <- survcure(Surv(time, status) ~ trt|trt,
#                family = "poisson",
#                baseline = weibull("ph"),
#                data = dados,
#                init = 0)
#
# po <- survcure(Surv(time, status) ~ trt|trt,
#                family = "poisson",
#                baseline = weibull("po"),
#                data = dados,
#                init = 0)
#
# coef(ph)
# coef(po)
# coef(yp)
# beta
# psi
# phi
# summary(yp)
#


ekm <- survival::survfit(Surv(time, status) ~ trt, data = dados)
ggsurv(ekm)

library(YPPE)
library(YPBP)
pe <- yppe(Surv(time, status) ~ trt, data = dados, init = 0)
bp <- ypbp(Surv(time, status) ~ trt, data = dados, init = 0)
coef(pe)
c(psi, phi)
newdata <- data.frame(trt = unique(dados$trt))
St <- survfit(bp, newdata = newdata)
plot(ekm, col = 1:2)
lines(sort(dados$time), St[[2]], lty = 2)
lines(sort(dados$time), St[[1]], col = "red", lty = 2)

# mu <- 1
# u <- runif(10)
# s <- invAp(u, dist = "poisson", mu = mu)
# Spop <- exp(mu*(s-1))
# cbind(s, u, Spop, exp(-mu),exp(-mu)>u)
coef.survcure(yp)
coef(pe)
coef(bp)
c(beta, psi, phi)


summary(bp)
AIC(yp)
logLik(yp)
c(beta, psi, phi)
coef.survcure(yp)


bp_yp <- survcure(Surv(time, status) ~ trt|trt,
                    family = "poisson",
                    baseline = bp("yp"),
                    data = dados,
                    init = 0, m = ceiling(n^0.4))

weib_yp <- survcure(Surv(time, status) ~ trt|trt,
               family = "poisson",
               baseline = weibull("yp"),
               data = dados,
               init = 0)

coef.survcure(weib_yp)
coef.survcure(bp_yp)
c(beta, psi, phi)
coef.survcure(bp_yp)
