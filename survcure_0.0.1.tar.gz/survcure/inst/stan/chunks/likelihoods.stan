

// *****************************************************************
// Bernoulli

vector log_Spop_bernoulli(int n, vector Sz, vector mu){
  vector[n] aux = 1 - mu + mu .* Sz;
  vector[n] ls = log(aux);
  return(ls);
}

vector log_fpop_bernoulli(int n, vector lfz, vector mu){
  vector[n] lf = log(mu) + lfz;
  return(lf);
}


// *****************************************************************
// Poisson

vector log_Spop_poisson(int n, vector Sz, vector mu){
  vector[n] ls = - mu .* (1-Sz);
  return(ls);
}

vector log_fpop_poisson(int n, vector lfz, vector Sz, vector mu){
  vector[n] lf = log(mu) + lfz - mu .* (1-Sz);
  return(lf);
}


// *****************************************************************
// Negative Binomial (negbin)


// vector log_Spop_negbin(int n, vector Sz, vector mu, real nu){
//   vector[n] aux = 1 + nu*(mu .* (1-Sz));
//   vector[n] ls;
//   for(i in 1:n){
//     ls[i] = lmultiply(-1/nu, aux[i]);
//   }
//   return(ls);
// }
//
// vector log_fpop_negbin(int n, vector lfz, vector Sz, vector mu, real nu){
//   vector[n] aux = 1 + nu*(mu .* (1-Sz));
//   vector[n] lf;
//   for(i in 1:n){
//     lf[i] = log(mu[i]) + lfz[i] - lmultiply(1 + 1/nu, aux[i]);
//   }
//   return(lf);
// }

vector log_Spop_negbin(int n, vector Sz, vector mu, real nu){
  vector[n] aux = nu*(mu .* (1-Sz));
  vector[n] ls = - log1p(aux)/nu;
  return(ls);
}

vector log_fpop_negbin(int n, vector lfz, vector Sz, vector mu, real nu){
  vector[n] aux = nu*(mu .* (1-Sz));
  vector[n] lf = log(mu) + lfz - (1 + 1/nu)*log1p(aux);
  return(lf);
}


// *****************************************************************
// Bell

vector log_Spop_bell(int n, vector Sz, vector theta){
  vector[n] ls = exp(theta .* Sz) - exp(theta);
  return(ls);
}

vector log_fpop_bell(int n, vector lfz, vector Sz, vector theta){
  vector[n] lf = exp(theta .* Sz) - exp(theta) + lfz + log(theta) + theta .* Sz ;
  return(lf);
}


// *****************************************************************
// Generic log-likelihood expression

vector logLikelinood(vector status, vector lfz, vector Sz, vector eta,
                     int count_dist, int link){

  int n = num_elements(status);
  vector[n] loglik;
  vector[n] lfpop;
  vector[n] lSpop;
  vector[n] theta;
  vector[n] mu;

  if(count_dist == 1){
    // Bernoulli
    mu = linkinv_bern(eta, link);
    lSpop = log_Spop_bernoulli(n, Sz, mu);
    lfpop = log_fpop_bernoulli(n, lfz, mu);
  }else if(count_dist == 2){
    // Poisson
    mu = linkinv_count(eta, link);
    lSpop = log_Spop_poisson(n, Sz, mu);
    lfpop = log_fpop_poisson(n, lfz, Sz, mu);
  }else{
    // Bell
    mu = linkinv_count(eta, link);
    theta = lambertW(mu);
    lSpop = log_Spop_bell(n, Sz, theta);
    lfpop = log_fpop_bell(n, lfz, Sz, theta);
  }

  loglik = status .* lfpop + (1-status) .* lSpop;
  return(loglik);

}


// *****************************************************************
// Generic log-likelihood expression for negbin

vector logLikelinood2(vector status, vector lfz, vector Sz, vector eta,
                     int count_dist, int link, real nu){

  int n = num_elements(status);
  vector[n] loglik;
  vector[n] lfpop;
  vector[n] lSpop;
  vector[n] theta;
  vector[n] mu;

  mu = linkinv_count(eta, link);
  lSpop = log_Spop_negbin(n, Sz, mu, nu);
  lfpop = log_fpop_negbin(n, lfz, Sz, mu, nu);

  loglik = status .* lfpop + (1-status) .* lSpop;
  return(loglik);

}



