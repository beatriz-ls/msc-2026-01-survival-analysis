
  vector inv_logit2(vector lp){
    int n = num_elements(lp);
    vector[n] x;
    for(i in 1:n){
       x[i] = 1/(1+exp(-lp[i]));
    }
    return(x);
  }

  /**
   * Code extracted/adapted from R package rstanarm
   *
   * @param eta Linear predictor vector
   * @param link An integer indicating the link function
   * @return A vector, i.e. inverse-link(eta)
   */
  vector linkinv_count(vector eta, int link) {
    if (link == 1)      return exp(eta);     // log
    else if (link == 2) return eta;          // identity
    else if (link == 3) return(square(eta)); // sqrt
    else reject("Invalid link");
    return eta; // never reached
  }


  /**
   * * Code extracted/adapted from R package rstanarm
   *
   * @param eta Linear predictor vector
   * @param link An integer indicating the link function
   * @return A vector, i.e. inverse-link(eta)
   */
  vector linkinv_bern(vector eta, int link) {
    //if (link == 1)      return(inv_logit(eta)); // logit
    if (link == 1)      return(inv_logit2(eta)); // logit
    else if (link == 2) return(Phi(eta)); // probit
    else if (link == 3) return(inv_cloglog(eta)); // cloglog
    else if (link == 4) return(atan(eta) / pi() + 0.5);  // cauchit
    else reject("Invalid link");
    return eta; // never reached
  }




  // vector linkinv_count2(vector eta, int link){
  //   vector[num_elements(eta)] out;
  //   if (link == 1){
  //     out = exp(eta);    // log
  //     return out;
  //   }else if (link == 2){
  //     out = eta;          // identity
  //     return out;
  //   }else if (link == 3){
  //     out = square(eta);
  //     return out; // sqrt
  //   }
  //   else reject("Invalid link");
  //   return eta; // never reached
  // }
