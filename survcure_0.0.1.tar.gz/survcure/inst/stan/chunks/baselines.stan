

// *****************************************************************
// Bernstein Polynomials:


vector lh0_bp(matrix g, vector gamma, real tau){
  return( log( g*gamma) - log(tau) );
}

vector H0_bp(matrix G, vector gamma){
  return( G*gamma );
}


vector lh0_bp_aft(vector time, vector gamma, vector exp_eta, int n, int m){
  matrix[n, m] g;
  vector[n] y = time ./ exp_eta;
  real tau = max(y) + 1e-8;
  vector[n] aux = y ./ tau;
  for(i in 1:n){
       for(j in 1:m){
          g[i, j] = exp(beta_lpdf(aux[i] | j, m - j + 1));
       }
     }
  return( log( g*gamma) - log(tau) );
}



vector H0_bp_aft(vector time, vector gamma, vector exp_eta, int n, int m){
  matrix[n, m] G;
  vector[n] y = time ./ exp_eta;
  real tau = max(y) + 1e-8;
  vector[n] aux = y ./ tau;
  for(i in 1:n){
       for(j in 1:m){
          G[i, j] = exp(beta_lcdf(aux[i] | j, m - j + 1));
       }
     }
  return( G*gamma );
}


// *****************************************************************
// Piecewise Exponential (PE) distribution:

vector lh0_pe(int[] idt, vector gamma, real tau){
 return( log(gamma[idt]) - log(tau) );
}

vector H0_pe(matrix ttt, vector gamma){
 return( ttt*gamma );
}


// vector lh0_pe_aft(vector time, vector gamma, vector rho, vector exp_eta, int[] idt, int n, int m){
//   vector[n] y = time ./ exp_eta;
//   matrix[n, m] ttt = TTT(y, rho);
//   return( log(gamma[idt]) -ttt*gamma );
// }
//
//
//
// vector H0_pe_aft(vector time, vector gamma, vector rho, vector exp_eta, int[] idt, int n, int m){
//   vector[n] y = time ./ exp_eta;
//   matrix[n, m] ttt = TTT(y, rho);
//   return( ttt*gamma );
// }



// *****************************************************************
// Weibull (Weib) distribution:

vector lh0_weib(vector y, vector gamma, real tau){
  // JAGS parametrization for the Weibull distribution
  // gamma[1]: shape parameter
  // gamma[2]: scale parameter
  return( log(gamma[1]) + log(gamma[2]) + (gamma[1] - 1)*log(y) - log(tau) );
  //return( log(gamma[1]) + log(gamma[2]) + lmultiply(gamma[1] - 1, y) - log(tau) );
}

vector H0_weib(vector y, vector gamma){
  // JAGS parametrization for the Weibull distribution
  // gamma[1]: shape parameter
  // gamma[2]: scale parameter
  // return( gamma[2] * exp( lmultiply(gamma[1], y) );
  return( gamma[2] * exp( gamma[1]*log(y) ) );
}


vector lh0_weib_aft(vector time, vector gamma, vector eta){
  // JAGS parametrization for the Weibull distribution
  // gamma[1]: shape parameter
  // gamma[2]: scale parameter
  return( log(gamma[1]) + log(gamma[2]) + (gamma[1] - 1)*(log(time) - eta ) );
}

vector H0_weib_aft(vector time, vector gamma, vector eta){
  // JAGS parametrization for the Weibull distribution
  // gamma[1]: shape parameter
  // gamma[2]: scale parameter
  return( gamma[2] * exp(gamma[1]*(log(time) - eta)) );
}


