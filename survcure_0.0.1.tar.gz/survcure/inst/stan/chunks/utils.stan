
real lambertW0(real x){
  real y;
  real w;
  y = sqrt( 1 + exp(1) *x);
  w =-1 + 2.036 * log( (1 + 1.14956131 * y)/(1 + 0.45495740*log(1+y)) );
  w = (w/(1+w)) * ( 1 + log(x/w) );
  w = (w/(1+w)) * ( 1 + log(x/w) );
  w = (w/(1+w)) * ( 1 + log(x/w) );
  return(w);
}



vector lambertW(vector x){
  int n = num_elements(x);
  real y;
  vector[n] w;
  for(i in 1:n){
    w[i] = lambertW0(x[i]);
  }
  return(w);
}




 matrix TTT(vector time, vector rho){
  int n = num_elements(time);
  int m = num_elements(rho) - 1;
  vector[2] aux;
  matrix[n, m] ttt;
  for(i in 1:n){
      for(j in 1:m){
        aux[1] = time[i];
        aux[2] = rho[j+1];
        ttt[i, j] = (min(aux) - rho[j])*(time[i] - rho[j] > 0);
      }
  }
  return(ttt);
}


int[] IDT(vector time, vector rho, int n){
  int j;
  int idt[n];
    for(i in 1:n){
      j = 0;
      while(time[i] > rho[j+1]){
        j = j + 1;
      }
      idt[i] = j;
  }
  return(idt);
}

vector CDF(vector Ht){
  return -expm1(-Ht);
}


vector log_CDF(vector Ht){
  return log1m_exp(-Ht);
}
