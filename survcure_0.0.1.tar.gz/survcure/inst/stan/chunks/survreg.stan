
//------------------------------------------------------------------------------
// PH model

vector log_haz_ph(int n, vector lh0, vector lp){
  vector[n] ph = lh0 + lp;
  return ph;
}

vector log_surv_ph(int n,  vector H0,  vector lp){
  vector[n] ph = - H0 .* exp(lp);
  return ph;
}

// vector log_cdf_ph(int n,  vector H0,  vector lp){
//   vector[n] Ht = H0 .* exp(lp);
//   return log_CDF(Ht);
// }

vector surv_ph(int n,  vector H0,  vector lp){
  vector[n] ph = exp(- H0 .* exp(lp));
  return ph;
}

vector log_dens_ph(int n, vector lh0, vector H0,  vector lp){
  vector[n] ph = lh0 + lp - H0 .* exp(lp);
  return ph;
}

//------------------------------------------------------------------------------
// P0 model

vector log_haz_po(int n, vector lh0, vector H0, vector lp){
  vector[n] Rt = expm1(H0) .* exp(lp);
  vector[n] po =  H0 + lh0 + lp - log1p(Rt);
  return po;
}

vector log_surv_po(int n, vector H0, vector lp){
  vector[n] Rt = expm1(H0) .* exp(lp);
  vector[n] po = - log1p(Rt);
  return po;
}

vector surv_po(int n, vector H0, vector lp){
  vector[n] po = exp(log_surv_po(n, H0, lp));
  return po;
}

vector log_dens_po(int n, vector lh0, vector H0, vector lp){
  vector[n] Rt = expm1(H0) .* exp(lp);
  vector[n] po =  H0 + lh0 + lp - 2*log1p(Rt);
  return po;
}


//------------------------------------------------------------------------------
// YP model

vector surv_yp(int n,  vector H0,  vector lp_short, vector lp_long, vector ratio){
  vector[n] R0 = expm1(H0);
  vector[n] aux = ratio .* R0;
  vector[n] yp = exp(-exp(lp_long) .* log1p(aux));
  return yp;
}

vector log_dens_yp(int n, vector lh0, vector H0, vector lp_short, vector lp_long, vector ratio){
  vector[n] R0 = expm1(H0);
  vector[n] aux = ratio .* R0;
  vector[n] yp = lp_short - log1p(aux) + lh0 + H0 - exp(lp_long) .* log1p(aux);
  return yp;
}

//------------------------------------------------------------------------------
// AFT model

vector log_haz_aft(int n, vector lh0, vector lp){
  vector[n] aft = -lp + lh0;
  return aft;
}

vector log_surv_aft(int n, vector H0){
  vector[n] aft = -H0;
  return aft;
}


vector log_dens_aft(int n, vector lh0, vector H0, vector lp){
  vector[n] aft = -lp + lh0 - H0;
  return aft;
}



