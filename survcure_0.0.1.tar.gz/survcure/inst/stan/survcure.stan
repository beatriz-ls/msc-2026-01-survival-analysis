
functions{
#include /inst/stan/chunks/utils.stan
#include /inst/stan/chunks/baselines.stan
#include /inst/stan/chunks/links.stan
#include /inst/stan/chunks/survreg.stan
#include /inst/stan/chunks/likelihoods.stan
}

data{

  int<lower=1> n;
  int<lower=1> m;
  int<lower=1> p;
  int<lower=0> q;

  vector[n] time;
  vector<lower=0, upper=1>[n] status;
  matrix[n, p] X1;
  matrix[q == 0 ? 0 : n, q] X2;

  int<lower=1, upper=4> count_dist;
  int<lower=1, upper=5> promo_dist;
  int<lower=1, upper=3> reg_incidence;
  int<lower=1, upper=5> link;
  int<lower=0, upper=1> is_negbin;

  int idt[promo_dist == 2 ? n : 0];
  vector[promo_dist == 2 ? m+1 : 0] rho;
  matrix[promo_dist == 2 ? n : 0, promo_dist == 2 ? m : 0] ttt;
  matrix[promo_dist == 3 ? n : 0, promo_dist == 3 ? m : 0] g;
  matrix[promo_dist == 3 ? n : 0, promo_dist == 3 ? m : 0] G;

  real<lower=0> tau;

}

transformed data{
  vector[n] y = time/tau;
}

parameters{

  vector[p] beta;
  vector[q == 0 ? 0 : q] psi;
  vector[reg_incidence == 3 ? q : 0] phi;
  vector<lower=0>[m] gamma;
  real<lower=0> nu[is_negbin ? 1 : 0];

}

model{

  vector[n] lfz;
  vector[n] Sz;
  vector[n] loglik;
  vector[n] eta1 = X1*beta;
  vector[q == 0 ? 0 : n] eta2;
  vector[reg_incidence == 3 ? n : n] lp_short;
  vector[reg_incidence == 3 ? n : n] lp_long;
  vector[reg_incidence == 3 ? n : n] ratio;
  vector[n] lh0;
  vector[n] H0;


  //***************************************************************
  // Choosing the baseline distribution for the promotion times:

  if(promo_dist == 1){
    lh0 = lh0_weib(y, gamma, tau);
    H0 = H0_weib(y, gamma);
  }else if(promo_dist == 2){
    lh0 = lh0_pe(idt, gamma, tau);
    H0 = H0_pe(ttt, gamma);
  }else{
    lh0 = lh0_bp(g, gamma, tau);
    H0 = H0_bp(G, gamma);
  }

  if(q == 0){
    Sz = exp(-H0);
    lfz = lh0 - H0;
  }else{
    if(reg_incidence == 1){
      eta2 = X2*psi;
      Sz = surv_ph(n, H0, eta2);
      lfz = log_dens_ph(n, lh0, H0, eta2);
    }else if(reg_incidence == 2){
      eta2 = X2*psi;
      Sz = surv_po(n, H0, eta2);
      lfz = log_dens_po(n, lh0, H0, eta2);
    }else{
      lp_short = X2*psi;
      lp_long = X2*phi;
      ratio = exp(X2*(psi-phi));
      Sz = surv_yp(n, H0, lp_short, lp_long, ratio);
      lfz = log_dens_yp(n, lh0, H0, lp_short, lp_long, ratio);
    }
  }

  if(is_negbin == 1){
    loglik = logLikelinood2(status, lfz, Sz, eta1, count_dist, link, nu[is_negbin]);
  }else{
    loglik = logLikelinood(status, lfz, Sz, eta1, count_dist, link);
  }

  target += sum(loglik);

}
