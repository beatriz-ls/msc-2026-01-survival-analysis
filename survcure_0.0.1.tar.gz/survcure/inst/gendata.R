




#' @export
invAp <- function(u,
                  dist = c("bernoulli", "poisson", "negbin", "bell"),
                  theta, nu = NULL){
  dist <- match.arg(dist)
  inv <- switch (dist,
                 bernoulli = (u - 1 + theta)/theta,
                 poisson = 1 - exp(u)/theta,
                 negbin = 1 - (-1+u^(-nu))/(nu*theta),
                 bell = log(log(u) + exp(theta))/theta
  )
  return(inv)
}



invHaz <- function(x, lambda, kappa, gamma, dist){
  dist <- match.arg(dist)
  inv <- switch (dist,
                 weibull = (x/gamma[1])^(1/gamma[2]) #gamma[1]: shape; gamma[2]: rate
  )
  return(inv)
}


rYP <- function(u, Z, psi, phi, gamma, dist){
  # psi = phi: PH
  # phi = 0: PO
  # psi != phi: YP
  Z <- as.matrix(Z)
  ratio <- as.numeric(exp(Z%*%(phi-psi)))
  kappa <- exp(Z%*%phi)
  w <- as.numeric((u^(-1/kappa) - 1)*ratio)
  r <- log(1+w)
  time <- switch (dist,
                  "1" = (r/gamma[2])^(1/gamma[1])  # Weibull (JAGS parametrization)
  )
  time <- (r/gamma[2])^(1/gamma[1])
  return(time)
}


probCure <- function(family, mu, nu = NULL){
  prob <- switch (family[[1]],
    "1" = 1-mu,
    "2" = exp(-mu),
    "3" = (1+nu*mu)^(-1/nu),
    "4" = exp(-exp(LambertW::W(mu))+1)
  )
  return(prob)
}


rsurvcure <- function(family = c("bernoulli", "poisson", "negbin",  "bell"),
                      baseline = "weibull",
                      X1, X2, beta, psi, phi, gamma, nu = NULL, max_fu){
  family <- extract_family(family)
  baseline <- extract_baseline(baseline)
  n <- nrow(X1)
  u <- runif(n)
  mu <- invlinks(family, as.numeric(X1%*%beta))

  cure <- probCure(family, mu = mu, nu = nu)
  is_cured <- u <= cure
  t <- c()
  time <-
  status <- c()
  c <- runif(n, 0, max_fu)
  for(i in 1:n){
    if(isTRUE(is_cured[i])){
      t[i] <- Inf
      status[i] <- 0
    }else{
      t[i] <- rYP(u[i], X2[i,], psi, phi, gamma, dist = baseline$baseline)
    }
    time[i] <- min(t[i], c[i])
    status[i] <- as.numeric(t[i] < c[i])
  }

  return(cbind(time, status, cured = as.numeric(is_cured)))
}
