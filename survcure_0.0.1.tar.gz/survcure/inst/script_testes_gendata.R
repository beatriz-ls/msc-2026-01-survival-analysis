

Rt <- function(t, gamma){
  Ht <- gamma[2]*(t^(gamma[1]))
  Rt <- exp(Ht) - 1
  return(Rt)
}

Sz <- function(t, lambda, kappa, gamma){
  Rt0 <- Rt(t, gamma)
  return( (1+lambda*Rt0/kappa)^(-kappa) )
}


surv <- function(t, theta, lambda, kappa, gamma){
  Fz <- 1-Sz(t, lambda, kappa, gamma)
  Spop <- exp(-theta*Fz)
  #Spop = exp(exp(theta*Sz(t, lambda, kappa)) - exp(theta))
  return(Spop)
}


gamma <- c(1.5, 1)
psi <- 1
phi <- -0.5
beta <- c(0.2, -0.2)
theta <- c(exp(beta[1]), exp(sum(beta)))
t <- seq(0, 4, by = 0.1)
St1 <- surv(t, theta = theta[1], lambda = 1, kappa = 1, gamma = gamma)
St2 <- surv(t, theta = theta[2], lambda = exp(psi), kappa = exp(phi), gamma = gamma)
plot(t, St1, type = "l", ylim = c(0,1))
lines(t, St2, col = "red")


