

library(survcure)
library(tidyverse)

data("e1690")
head(e1690)


e1690 <- e1690 %>%
  select(failtime, failcens, survtime, survcens, trt, age, sex) %>%
  filter(failtime > 0) %>%
  mutate(
    trt = as.factor(trt),
    age = as.numeric(scale(age)),
    sex = as.factor(sex)
  ) %>%
  na.exclude()

sapply(e1690, summary)


weib <- survcure(formula = Surv(survtime, survcens) ~ trt + age+ sex,
                 data = e1690, family = poisson("log"), baseline = "weibull",
                 init = 0)

ph <- survcure(formula = Surv(failtime, failcens) ~ trt + age+ sex|trt + age+ sex,
               data = e1690, family = poisson("log"), baseline = weibull("ph"))

po <- survcure(formula = Surv(failtime, failcens) ~ trt + age+ sex|trt + age+ sex,
                   data = e1690, family = poisson("log"), baseline = weibull("po"))

yp <- survcure(formula = Surv(failtime, failcens) ~ trt + age+ sex|trt + age+ sex,
                   data = e1690, family = poisson("log"), baseline = weibull("yp"))


anova(weib, ph, po, yp)

anova(weib, ph, po, yp)
anova(weib, ph)
anova(weib, po)

AIC(weib)
AIC(ph)
AIC(po)
AIC(yp)


library(survival)
ekm <- survfit(Surv(survtime, survcens) ~ trt, data = e1690)
plot(ekm, col = 1:2)
summary(yp)
