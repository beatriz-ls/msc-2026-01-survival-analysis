## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE------------------------------------------------------------
library(survcure)
library(tidyverse)
library(GGally)

# fixing the seed for the rng:
set.seed(1234567890)

beta <- c(0.5, -0.2, -0.1)
gamma <- c(0.9, 1); 
psi = 2
phi = -1 
n <- 500

# generating the set of explanatory variables:
covariates <- data.frame(
    trt = rbinom(n, 1, 0.5),
    age = rnorm(n)
  )

# generating the data set:
data <- rsurvcure(
    ~ trt + age|trt, covariates = covariates,
    incidence = "bell",
    latency = "weibull",
    gamma = gamma,
    beta = beta, 
    psi = psi,
    phi = phi,
    max_fu = 5
  )

glimpse(data)  
  

## -----------------------------------------------------------------------------
m <- ceiling(nrow(data)^0.4)
fit <- survcure(Surv(time, status) ~ trt + age|trt, data = data, 
                  incidence = "bell", latency = weibull("yp"), init = 0, m = m)
summary(fit)

## -----------------------------------------------------------------------------
newdata <- data.frame(
  trt = c(0, 1),
  age = c(0, 0)
)


ekm <- survfit(Surv(time, status)~trt, data = data)
surv <- survfit(fit, newdata = newdata)

surv <- data.frame(time = surv$time, surv1 = surv$surv[[1]], surv2 = surv$surv[[2]]) %>%
  pivot_longer(cols = 2:3, names_to = "trt", values_to = "surv")

ggsurv(ekm) + 
  ylim(0, 1) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt))


## -----------------------------------------------------------------------------

newdata1 <- data.frame(
  trt = 0,
  age = 0
)

newdata2 <- data.frame(
  trt = 1,
  age = 0
)

tcross <- cross_time(fit, newdata1, newdata2, nboot = 10)
tcross

ggsurv(ekm) +
  geom_line(data = surv, aes(x = time, y = surv, group = trt)) +
  geom_vline(data = tcross, aes(xintercept = time), color = "blue") +
  geom_vline(data = tcross, aes(xintercept = `2.5%`), color = "blue", linetype = "dashed") +
  geom_vline(data = tcross, aes(xintercept = `97.5%`), color = "blue", linetype = "dashed") +
  ylim(0, 1)



