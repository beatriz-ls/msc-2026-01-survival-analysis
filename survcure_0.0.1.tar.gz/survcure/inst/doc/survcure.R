## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE------------------------------------------------------------
library(survcure)
library(tidyverse)
library(GGally)

# loading the data
data(e1673)

# prepering the data for analysis:
e1673 <- e1673 %>%
  mutate(
    gender = as.factor(gender),
    age = as.numeric(scale(age)),
    ps = as.factor(ps)
  )

glimpse(e1673)  
  

## -----------------------------------------------------------------------------

none <- survcure(Surv(time, status) ~ gender + age + ps, data = e1673,
                  incidence = "bell", latency = "pe", init = 0)

ph <- survcure(Surv(time, status) ~ gender + age + ps | gender + age + ps, data = e1673,
                  incidence = "bell", latency = pe("ph"), init = 0)

po <- survcure(Surv(time, status) ~ gender + age + ps | gender + age + ps, data = e1673,
                  incidence = "bell", latency = pe("po"), init = 0)

yp <- survcure(Surv(time, status) ~ gender + age + ps | gender + age + ps, data = e1673,
                  incidence = "bell", latency = pe("yp"), init = 0)

## -----------------------------------------------------------------------------
summary(none)
summary(ph)

## -----------------------------------------------------------------------------
anova(none, ph)
anova(none, po)
anova(none, yp)
anova(ph, yp)
anova(po, yp)

## -----------------------------------------------------------------------------
AIC(none, ph, po, yp)

