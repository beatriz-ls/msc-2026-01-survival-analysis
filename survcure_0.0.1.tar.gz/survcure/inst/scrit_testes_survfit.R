
library(tidyverse)
library(GGally)

n <- 500
trt <- rbinom(n, 1, 0.5)

X1 <- cbind(1, trt)
X2 <- matrix(trt, ncol = 1)
beta <- c(0.5, -0.2)
psi <- 1
phi <- -0.5
gamma <- c(1.5, 1)
gamma <- c(0.9, 1); phi = -1; psi = 2   # usar esse!!!!
# gamma <- c(0.8, 1); phi = -1; psi = 1

mu0 <- exp(beta[1])
mu1 <- exp(sum(beta))
exp(-mu0)
exp(-mu1)


baseline <- "weibull"
family <- "poisson"
nu <- 1

# time <- seq(0.001, 4, length.out = 1000)
# X1 <- unique(matrix(c(1, 1, 0, 1), ncol = 2))
# X2 <- X1[, 2, drop = FALSE]
# lambda <- as.numeric(exp(X2%*%psi))
# kappa <- as.numeric(exp(X2%*%phi))
# mu <- as.numeric(exp(X1%*%beta))
# Ht0 <- gamma[2]*(time^gamma[1])
# Rt0 <- exp(Ht0) - 1
# Sz0 <- (1+lambda[1]*Rt0/kappa[1])^(-kappa[1])
# Sz1 <- (1+lambda[2]*Rt0/kappa[2])^(-kappa[2])
# St0 <- exp(-mu[1]*(1-Sz0))
# St1 <- exp(-mu[2]*(1-Sz1))
#
# plot(time, St0, type = "l", ylim = c(0,1))
# lines(time, St1, col = "red")
# lines(time, rep(exp(-mu0), n), lty = 2)
# lines(time, rep(exp(-mu1), n), lty = 2, col = 2)




dados <- rsurvcure(
  ~ trt|trt, covariates = covariates,
  family = "bell",
  baseline = "weibull",
  gamma = gamma,
  beta = beta,
  psi = psi,
  phi = phi,
  max_fu = 5
)

apply(dados, 2, mean)



yp <- survcure(Surv(time, status) ~ trt|trt,
               family = "bell",
               baseline = bp("yp"),
               data = dados,
               init = 0, m = ceiling(n^0.4))

yp <- survcure(Surv(time, status) ~ trt|trt,
               family = "poisson",
               baseline = pe("yp"),
               data = dados,
               init = 0, m = ceiling(n^0.4))

yp <- survcure(Surv(time, status) ~ trt|trt,
               family = "bell",
               baseline = weibull("yp"),
               data = dados,
               init = 0)
summary(yp)
coef.survcure(yp)
c(beta, psi, phi)

newdata <- data.frame(trt = 0:1)
out <- survfit.survcure(yp, newdata)
df <- data.frame(time = out$time, surv1 = out$surv[[1]], surv2 = out$surv[[2]])
df <- df %>%
  pivot_longer(cols = 2:3, names_to = "gender", values_to = "surv")
glimpse(df)


ekm <- survival::survfit(Surv(time, status) ~ trt, data = dados)
g <- ggsurv(ekm)

g +
  geom_line(data = df, aes(x = time, y = surv, group = gender))

