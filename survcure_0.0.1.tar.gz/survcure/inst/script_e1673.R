
library(tidyverse)
library(survcure)
library(GGally)

data(e1673)
head(e1673)

e1673 <- e1673 %>%
  mutate(
    age = (age-mean(age))/sd(age),
  )
glimpse(e1673)



fit0 <- survcure(Surv(time, status)~age+gender+ps,
                 latency = "bp", incidence = "poisson",
                 data = e1673, init=0)

fit1 <- survcure(Surv(time, status)~age+gender+ps,
                    latency = "weibull", incidence = "poisson",
                    data = e1673, init=0)

fit2 <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = weibull("ph"), incidence = "poisson",
                 data = e1673, init=0)

fit3 <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = weibull("po"), incidence = "poisson",
                 data = e1673, init=0)

fit4 <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = weibull("yp"), incidence = poisson(link = "log"),
                 data = e1673)

fit5 <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = pe("yp"), incidence = poisson(link = "log"),
                 data = e1673)


summary(fit1)
summary(fit2)
summary(fit3)
summary(fit4)
anova.survcure(fit1, fit2, fit3, fit4)


# testing warning message:
anova.survcure(fit1, fit2, fit3, fit4)


teste <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                 latency = pe("ph"), incidence = poisson(link = "log"),
                 data = e1673)
summary(teste)


teste <- survcure(Surv(time, status)~age+gender+ps|age+gender+ps,
                  latency = pe("ph"), incidence = bell(link = "log"),
                  data = e1673, m = 10)
summary(teste)




time <- e1673$time
object <- teste
X <- model.matrix.survcure(teste)
X1 <- X$X1
X2 <- X$X2
St <- survcureSurv(time, object, X1, X2)
St
plot(sort(time), sort(St, decreasing = TRUE))

newdata <- data.frame(
  age = c(0, 0),
  gender = c(0, 1),
  ps = c(0, 0)
)



teste <- survcure(Surv(time, status)~gender|gender,
                  latency = pe("ph"), incidence = bell(link = "log"),
                  data = e1673, m = 10)


teste <- survcure(Surv(time, status)~gender|gender,
                  latency = weibull("ph"), incidence = bell(link = "log"),
                  data = e1673, m = 10)

teste <- survcure(Surv(time, status)~gender|gender,
                  latency = bp("yp"), incidence = poisson(link = "log"),
                  data = e1673, m = 10)

summary(teste)
out <- survfit.survcure(teste, newdata)



ekm <- survival::survfit(Surv(time, status)~gender, data = e1673)
g1 <- ggsurv(ekm)

t <- out$time
S1 <- out$surv[[1]]
S2 <- out$surv[[2]]


df <- data.frame(time = out$time, surv1 = out$surv[[1]], surv2 = out$surv[[2]])
df <- df %>%
  pivot_longer(cols = 2:3, names_to = "gender", values_to = "surv")
glimpse(df)

g2 <- ggplot(df, aes(x = time, y = surv, color = gender)) +
  geom_line()


library(gridExtra)
gridExtra::grid.arrange(g1, g2, ncol = 2)



g1 +
  geom_line(data = df, aes(x = time, y = surv, group = gender))
coef(teste)
summary(teste)
