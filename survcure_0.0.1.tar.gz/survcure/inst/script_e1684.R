
#-------------------------------------------------------------------------------
# reproduz exemplo pág. 168 do livro Bayesian Survival Analysis
library(survcure)
library(tidyverse)

data("e1684")
head(e1684)

data("e1684")
glimpse(e1684)
e1684 <- e1684 %>%
  select(failtime, failcens, survtime, survcens, trt, age, sex, ps) %>%
  filter(failtime > 0) %>%
  mutate(
    age = as.numeric(scale(age)),
    sex = as.factor(sex)
  ) %>%
  na.exclude()

weib <- survcure(formula = Surv(survtime, survcens) ~ age + sex + ps,
                 data = e1684, incidence = poisson("log"), latency = "weibull",
                 init = 0)
summary(weib)
#-------------------------------------------------------------------------------

library(survcure)
library(tidyverse)

data("e1684")
head(e1684)


e1684 <- e1684 %>%
  select(failtime, failcens, survtime, survcens, trt, age, sex) %>%
  filter(failtime > 0) %>%
  mutate(
    trt = as.factor(trt),
    age = as.numeric(scale(age)),
    sex = as.factor(sex)
  ) %>%
  na.exclude()

sapply(e1684, summary)


weib <- survcure(formula = Surv(survtime, survcens) ~ trt + age+ sex,
                 data = e1684, family = poisson("log"), baseline = "bp",
                 init = 0)

ph <- survcure(formula = Surv(failtime, failcens) ~ trt + age+ sex|trt + age+ sex,
               data = e1684, family = poisson("log"), baseline = bp("ph"), init = 0)

po <- survcure(formula = Surv(failtime, failcens) ~ trt + age+ sex|trt + age+ sex,
               data = e1684, family = poisson("log"), baseline = bp("po"), init = 0)

yp <- survcure(formula = Surv(failtime, failcens) ~ trt + age+ sex|trt + age+ sex,
               data = e1684, family = poisson("log"), baseline = bp("yp"), init = 0)


anova(weib, ph, po, yp)
anova(weib, ph)
anova(weib, po)

AIC(weib)
AIC(ph)
AIC(po)
AIC(yp)


library(survival)
ekm <- survfit(Surv(survtime, survcens) ~ trt, data = e1684)
plot(ekm, col = 1:2)
summary(yp)
