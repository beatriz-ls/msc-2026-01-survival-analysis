# Computes the Bernstein polynomial's bases. (note: for computation stability, b is not divided by tau here)
bp_bases <- function(time, degree, tau){
  n <- length(time)
  y <- time/tau
  b <- matrix(nrow=n, ncol=degree)
  B <- matrix(nrow=n, ncol=degree)
  for(k in 1:degree){
    b[,k] <- stats::dbeta(y, k, degree - k + 1)
    B[,k] <- stats::pbeta(y, k, degree - k + 1)
  }
  return(list(b=b, B=B))
}

# Computes the total time under test (PE distribution)
TTT <- function(time, rho){
  n <- length(time)
  m <- length(rho) - 1
  ttt <- matrix(nrow = n, ncol = m)
  for(i in 1:n){
    for(j in 1:m){
      ttt[i,j] <- (min(time[i], rho[j+1]) - rho[j])*(time[i] - rho[j]>0)
    }
  }
  return(ttt)
}



#---------------------------------------------
#' Variance-covariance matrix
#'
#' @aliases vcov.survcure
#' @description This function extracts and returns the variance-covariance matrix associated with the regression coefficients when the maximum likelihood estimation approach is used in the model fitting.
#' @export
#' @importFrom stats vcov
#' @param object an object of the class survcure.
#' @param ... further arguments passed to or from other methods.
#' @return  the variance-covariance matrix associated with the regression coefficients.
#'
#' @examples
#' \donttest{
#' bp <- survcure(Surv(time, status)~age+gender+ps,
#'               latency = "bp",
#'               incidence = "poisson",
#'               data = e1673)
#' vcov(bp)
#' }
#'
vcov.survcure <- function(object, ...){
  p <- object$p
  q <- object$q
  if(object$reg < 3){
    V <- MASS::ginv(object$fit$hessian)[1:(p+q), 1:(p+q)]
    labels1 <- paste0("beta", 0:(p-1))
    if(q>0){
      labels2 <- paste0("psi", 1:q)
      labels <- c(labels1, labels2)
    }else{
      labels <- labels1
    }
  }else{
    V <- MASS::ginv(object$fit$hessian)[1:(p+2*q), 1:(p+2*q)]
    labels1 <- paste0("beta", 0:(p-1))
    if(q>0){
      labels2 <- paste0("psi", 1:q)
      labels3 <- paste0("phi", 1:q)
      labels <- c(labels1, labels2, labels3)
    }else{
      labels <- labels1
    }
  }


  colnames(V) <- labels
  rownames(V) <- labels
  return(V)
}



#---------------------------------------------
#' Estimated regression coefficients
#'
#' @aliases coef.survcure
#' @export
#' @param object an object of the class survcure
#' @param ... further arguments passed to or from other methods
#' @return  the estimated regression coefficients
#'
#'
coef.survcure <- function(object, ...){
  p <- object$p
  q <- object$q
  if(object$reg < 3){
    coeffs <- object$fit$par[1:(q+p)]
  }else{
    coeffs <- object$fit$par[1:(2*q+p)]
  }

  return(coeffs)
}


#---------------------------------------------
#' Confidence intervals for the regression coefficients
#'
#' @aliases confint.survcure
#' @export
#' @param object an object of the class survcure.
#' @param level the confidence level required.
#' @param parm a specification of which parameters are to be given confidence intervals, either a vector of numbers or a vector of names. If missing, all parameters are considered.
#' @param ... further arguments passed to or from other methods.
#' @return  100(1-alpha) confidence intervals for the regression coefficients.
#'
#'
confint.survcure <- function(object, parm = NULL, level=0.95, ...){
  p <- object$p
  q <- object$q
  if(object$reg < 3){
    par.hat <- object$fit$par[1:(q+p)]
  }else{
    par.hat <- object$fit$par[1:(2*q+p)]
  }
  alpha <- 1-level
  d <- stats::qnorm(1 - alpha/2)*se(object)
  lower <- par.hat - d
  upper <- par.hat + d
  CI <- data.frame(
    lower = lower,
    upper = upper)
  labels <- round(100*(c(alpha/2, 1-alpha/2)),1)
  names(CI) <- paste0(labels, "%")
  return(CI)
}


# internal function used to compute AIC (several models)
get_arg_names <- function(...) {
  argnames <- sys.call()
  paste0(lapply(argnames[-1], as.character))
}

#' Akaike information criterion
#' @aliases AIC.survcure
#' @param object an object of the class survcure.
#' @param ... further arguments passed to or from other methods.
#' @param k numeric, the penalty per parameter to be used; the default k = 2 is the classical AIC.
#' @return the Akaike information criterion
#' @export
#'

AIC.survcure <- function(object, ..., k = 2){
  objects <- c(as.list(environment()), list(...))
  argnames <- sys.call()
  argnames <- paste0(lapply(argnames[-1], as.character))
  k <- objects[[2]]
  objects <- objects[-2]
  J <- nargs()
  aic <- c()
  for(j in 1:J){
    loglik <- objects[[j]]$fit$value
    npar <- objects[[j]]$npar
    aic[j] <- -2*loglik + k*npar
  }
  if(length(argnames)>1){
    names(aic) <- argnames
    aic <- sort(aic)
  }
  return(aic)
}

# AIC.survcure <- function(object, ..., k = 2){
#   if(class(object)[1]=="survcure"){
#     loglik <- object$fit$value
#     npar <- object$npar
#     aic <- -2*loglik + k*npar
#     return(aic)
#   }else{
#     return(NA)
#   }
# }


#' Extract Log-Likelihood
#' @aliases logLik.survcure
#' @param object an object of the class survcure.
#' @param ... further arguments passed to or from other methods.
#' @return the log-likelihood associated with the fitted model.
#' @export
#'
logLik.survcure <- function(object, ...){
  return(object$fit$value)
}


#' Implemented link functions for the mixture cure rate model
#' @export
#' @aliases bernoulli
#' @description This function is used to specify different link functions for the count component of the mixture cure rate model.
#' @param link desired link function; currently implemented links are: logit, probit, cloglog and cauchit.
#' @return A list containing the codes associated with the count distribution assumed for the latent variable N and the chosen link.
#'
bernoulli <- function(link = c("logit", "probit", "cloglog", "cauchit")){
  link <- match.arg(link)
  link <- switch(link,
                logit = 1,
                probit = 2,
                cloglog = 3,
                cauchit = 4
                )
  out <- list(count_dist = 1, link = link)
  return(out)
}



#' Implemented link functions for the promotion time cure rate model with Poisson distribution.
#' @export
#' @aliases poisson
#' @description This function is used to specify different link functions for the count component of the promotion time cure rate model.
#' @param link desired link function; currently implemented links are: log, identity and sqrt.
#' @return A list containing the codes associated with the count distribution assumed for the latent variable N and the chosen link.
#'
poisson <- function(link = c("log", "identity", "sqrt")){
  link <- match.arg(link)
  link <- switch(link,
                log = 1,
                identity = 2,
                sqrt = 3
  )
  out <- list(count_dist = 2, link = link)
  return(out)
}

#' Implemented link functions for the promotion time cure rate model with negative binomial distribution.
#' @export
#' @aliases negbin
#' @description This function is used to specify different link functions for the count component of the promotion time cure rate model.
#' @param link desired link function; currently implemented links are: log, identity and sqrt.
#' @return A list containing the codes associated with the count distribution assumed for the latent variable N and the chosen link.
#'
negbin <- function(link = c("log", "identity", "sqrt")){
  link <- match.arg(link)
  link <- switch(link,
                 log = 1,
                 identity = 2,
                 sqrt = 3
  )
  out <- list(count_dist = 3, link = link)
  return(out)
}

#' Implemented link functions for the promotion time cure rate model with Bell distribution.
#' @export
#' @aliases bell
#' @description This function is used to specify different link functions for the count component of the promotion time cure rate model.
#' @param link desired link function; currently implemented links are: log, identity and sqrt.
#' @return A list containing the codes associated with the count distribution assumed for the latent variable N and the chosen link.
#'
bell <- function(link = c("log", "identity", "sqrt")){
  link <- match.arg(link)
  link <- switch(link,
                 log = 1,
                 identity = 2,
                 sqrt = 3
  )
  out <- list(count_dist = 4, link = link)
  return(out)
}


extract_incidence <- function(incidence = c("bernoulli", "poisson", "negbin",  "bell")){
  if(is.character(incidence[1])){
    count_dist <- match.arg(incidence)
    count_dist <- switch(count_dist,
      bernoulli = 1,
      poisson = 2,
      negbin = 3,
      bell = 4,)
    incidence <- list(count_dist = count_dist,
                   link = 1)
  }
  return(incidence)
}


#' latency distribution with a given regression structure.
#' @export
#' @aliases weibull.latency
#' @description This function is used to specify a latency distribution for the promotion times along with its (possible) regression structure.
#' @param survreg desired incidence of survival regression models; currently implemented regression models are: proportional hazards (ph - default option) and proportional odds (po) models.
#' @return A list containing the codes associated with the latency model assumed for the promotion times and the chosen regression model.
#'
weibull <- function(survreg = c("ph", "po", "yp")){
  survreg <- match.arg(survreg)
  survreg <- switch(survreg,
                    ph = 1,
                    po = 2,
                    yp = 3
  )
  out <- list(latency = 1, survreg = survreg)
  return(out)
}


#' latency distribution with a given regression structure.
#' @export
#' @aliases pe.latency
#' @description This function is used to specify a latency distribution for the promotion times along with its (possible) regression structure.
#' @param survreg desired incidence of survival regression models; currently implemented regression models are: proportional hazards (ph - default option) and proportional odds (po) models.
#' @return A list containing the codes associated with the latency model assumed for the promotion times and the chosen regression model.
#'
pe <- function(survreg = c("ph", "po", "yp")){
  survreg <- match.arg(survreg)
  survreg <- switch(survreg,
                ph = 1,
                po = 2,
                yp = 3
  )
  out <- list(latency = 2, survreg = survreg)
  return(out)
}

#' latency distribution with a given regression structure.
#' @export
#' @aliases bp.latency
#' @description This function is used to specify a latency distribution for the promotion times along with its (possible) regression structure.
#' @param survreg desired incidence of survival regression models; currently implemented regression models are: proportional hazards (ph - default option) and proportional odds (po) models.
#' @return A list containing the codes associated with the latency model assumed for the promotion times and the chosen regression model.
#'
bp <- function(survreg = c("ph", "po", "yp")){
  survreg <- match.arg(survreg)
  survreg <- switch(survreg,
                    ph = 1,
                    po = 2,
                    yp = 3
  )
  out <- list(latency = 3, survreg = survreg)
  return(out)
}


extract_latency <- function(latency = c("weibull", "pe", "bp")){
  if(is.character(latency[1])){
    latency <- match.arg(latency)
    latency <- switch(latency,
                         weibull = 1,
                         pe = 2,
                         bp = 3)
    latency <- list(latency = latency,
                survreg = 1)
  }
  return(latency)
}


invlinks <- function(incidence, lp){
  incidence <- extract_incidence(incidence)
  dist <- incidence$count_dist
  link <- incidence$link
  if(dist == 1){
    mu <- switch (link,
      "1" = 1/(1+exp(-lp)),
      "2" = qnorm(lp),
      "3" = 1 - exp(-exp(lp))
    )
  }else{
    mu <- switch (link,
      "1" = exp(lp),
      "2" = lp,
      "3" = sqrt(lp)
    )
  }
}



check_vcov <- function(object){
  H <- object$fit$hessian
  V <- MASS::ginv(H)
  test <- diag(V) > 0
  K <- length(object$fit$par)
  if(sum(test) == K){
    res <- 0
  }else{
    test <- eigen(V)$value >= 0
    if(sum(test) == K){
      res <- 1
    }else{
      test <- eigen(V)$value >= 0
      res <- 2
    }
  }
  return(res)
}


#' Extract Model Matrices from a survcure Object
#'
#' @aliases model.matrix.survcure
#' @description This function extracts the design matrices used in fitting a survcure model. It returns separate matrices for the latency component (X1) and the incidence component (X2) of the cure model.
#' @export
#' @param object an object of the class survcure.
#' @param ... further arguments passed to or from other methods.
#' @return A list containing two elements:
#' \describe{
#'   \item{X1}{the design matrix for the latency component (right-hand side 1 of the formula).}
#'   \item{X2}{the design matrix for the incidence component (right-hand side 2 of the formula), with the intercept column removed. Returns a try-error if no second component is specified.}
#' }
#'
#' @examples
#' \donttest{
#' bp <- survcure(Surv(time, status) ~ age + gender + ps,
#'                latency = "bp",
#'                incidence = "poisson",
#'                data = e1673)
#' model.matrix(bp)
#' }
#'
model.matrix.survcure <- function(object, ...){
  mf <- object$mf
  formula <- Formula::Formula(object$formula)
  Terms <- stats::terms(mf)
  resp <- stats::model.response(mf)
  time <- resp[,1]
  status <- resp[,2]
  X1 <- stats::model.matrix(formula, data = mf, rhs = 1)
  X2 <- suppressWarnings(try(stats::model.matrix(formula, data = mf, rhs = 2)[,-1, drop = FALSE], TRUE))
  return(list(X1 = X1, X2 = X2))
}



#---------------------------------------------
#' Generic S3 method se
#' @export
#' @param object a fitted model object.
#' @param ... further arguments passed to or from other methods.
#' @return the standard errors associated with a set of parameter estimators for a given model.
#'
se <- function(object, ...) UseMethod("se")

#---------------------------------------------
#' Estimated standard errors for the regression coefficients
#'
#' @aliases se.survcure
#' @export
#' @param object an object of the class survcure
#' @param ... further arguments passed to or from other methods
#' @return  the standard errors associated with a set of parameter estimators for a given survcure model.


se.survcure <- function(object, ...){
  se <- suppressWarnings(try(sqrt(diag(vcov(object)))))
  return(se)
}




#---------------------------------------------
#' Optimal m for PE and BP models
#'
#' @aliases optimal_m.survcure
#' @export
#' @param formula n object of class "formula" (or one that can be coerced to that class): a symbolic description of the model to be fitted.
#' @param data an optional data frame, list or environment (or object coercible by as.data.frame to a data frame) containing the variables in the model. If not found in data, the variables are taken from environment(formula), typically the environment from which survcure is called.
#' @param incidence the distribution assumed for the (latent) count variable in the promotion time cure rate model.
#' @param latency the latency distribution assumed to model the (latent) promotion times; currently available models: Weibull, piecewise exponential (PE) distribution, and Bernstein polynomials.
#' @param M maximum degree; If NULL, M is set to 20.
#' @param ... further arguments passed to other methods.
#' @return a data.frame with a grid of values of m and their associated AIC.
#'
optimal_m <- function(formula, data,
                      incidence = c("bernoulli", "poisson", "negbin", "bell"),
                      latency = c("pe", "bp"),
                      M = NULL, ...){
  mf <- stats::model.frame(formula=formula, data=data)
  # incidence <- match.arg(incidence)
  # latency <- match.arg(latency)
  resp <- stats::model.response(mf)
  time <- resp[, 1]
  n <- nrow(resp)
  if(is.null(M)){
    M <- min(ceiling(n^0.8), 20)
  }
  tb <- matrix(nrow = M, ncol = 2)

  pb <- progress::progress_bar$new(total = M)
  for(m in 1:M){
    pb$tick()
    Sys.sleep(1 / M)
    fit <- try(survcure(formula, data = data, latency = latency, incidence = incidence,
                        init = 0, m = m, hessian = FALSE), TRUE)
    if(is(fit, "try-error")){
      tb[m, ] <- c(m, NA)
    }else{
      tb[m, ] <- c(m, AIC(fit))
    }
  }

  colnames(tb) <- c("m", "AIC")
  tb <- as.data.frame(tb)
  return(tb)
}
