#' The 'survcure' package.
#'
#' @description Fitting of cure rate survival models based on the unified formulation of cure rate models proposed by \insertCite{2009Rodrigues}{survcure}
#' _PACKAGE
#' @name survcure-package
#' @aliases survcure-package
#' @useDynLib survcure, .registration = TRUE
#' @import methods
#' @import Rcpp
#' @import survival
#' @importFrom stats coef dbinom dpois model.matrix pchisq qnorm runif AIC
#' @importFrom rstan sampling
#' @importFrom Rdpack reprompt
#'
#' @references
#' Stan Development Team (2020). RStan: the R interface to Stan. R package version 2.21.2. https://mc-stan.org
#'
#' \insertRef{2001Ibrahim}{survcure}
#'
#' \insertRef{2009Rodrigues}{survcure}
#'
NULL
