

# *****************************************************************
# Bernoulli

Spop_bernoulli <- function(Sz, mu){
  surv <- 1- mu + mu * Sz;
  return(surv);
}


# *****************************************************************
# Poisson

Spop_poisson <- function(Sz, mu){
  surv <- exp(- mu*(1-Sz))
  return(surv);
}

# *****************************************************************
# Negative Binomial (negbin)

Spop_negbin <- function(Sz, mu, nu){
  surv <- (1+nu*mu*(1-Sz))^(-1/nu)
  return(surv)
}


# *****************************************************************
# Bell

Spop_bell <- function(Sz, mu){
  theta <- LambertW::W(mu)
  surv <- exp( exp(theta * Sz) - exp(theta) )
  return(surv)
}



# # *****************************************************************
#
# survcureSurv <- function(time, object, X1, X2){
#   info <- object$model_info
#   family <- info[1]
#   link <- info[2]
#   baseline <- info[3]
#   survreg <- info[4]
#   par <- object$fit$par
#   tau <- object$tau
#   y <- time/tau
#
#   p <- object$p
#   q <- object$q
#   m <- object$m
#   beta <- par[1:p]
#   if(q>0){
#     if(survreg == 3){
#       psi <- par[(p+1):(p+q)]
#       phi <- par[(p+q+1):(p+2*q)]
#       gamma <- par[(p+2*q+1):(p+2*q+m)]
#     }else{
#       psi <- par[(p+1):(p+q)]
#       gamma <- par[(p+q+1):(p+q+m)]
#     }
#
#   }
#   if(family == 3){
#     nu <- par[length(par)]
#   }
#
#   if(baseline == 1){
#     H0 <- H0_weib(y, gamma)
#   }else if(baseline == 2){
#     rho <- object$rho
#     ttt <- TTT(time, rho)/tau
#     H0 <- H0_pe(ttt, gamma)
#   }else{
#     G <- object$G
#     H0 <- H0_bp(G, gamma)
#   }
#
#
#   if(q == 0){
#     Sz <- exp(-H0)
#   }else{
#     if(survreg == 1){
#       lp2 = as.vector(X2%*%psi)
#       Sz <- surv_ph(H0, lp2)
#     }else if(survreg == 2){
#       lp2 = as.vector(X2%*%psi)
#       Sz = surv_po(H0, lp2)
#     }else{
#       lp_short = as.vector(X2%*%psi)
#       lp_long = as.vector(X2%*%phi)
#       Sz = surv_yp(H0, lp_short, lp_long)
#     }
#   }
#
#   family <- list(
#     count_dist = family,
#     link = link
#   )
#
#   mu = invlinks(family, as.numeric(X1%*%beta))
#   if(family[[1]] == 1){
#     #Bernoulli
#     Spop = Spop_bernoulli(Sz, mu)
#   }else if(family[[1]] == 2){
#     #Poisson
#     Spop = Spop_poisson(Sz, theta)
#   }else if(family[[1]] == 3){
#     # negbin
#     Spop = Spop_negbin(n, Sz, mu, nu)
#   }else{
#     #Bell
#     theta = LambertW::W(mu)
#     Spop = Spop_bell(Sz, theta)
#   }
#
#   return(Spop)
# }
#
