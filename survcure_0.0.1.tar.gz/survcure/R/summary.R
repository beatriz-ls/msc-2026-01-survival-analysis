#' Print the summary.survcure output
#'
#' @export
#' @param x an object of the class summary.survcure.
#' @param ... further arguments passed to or from other methods.
#' @return a summary of the fitted model.
print.summary.survcure <- function(x, ...){
  if(x$reg < 3){
    cat("Call:\n")
    print(x$call)
    cat("\n")
    cat("Cure fraction coefficients:\n")
    stats::printCoefmat(x$coefficients1, P.value=TRUE, has.Pvalue=TRUE)
    cat("\n")
    if(!is.null(x$coefficients2)){
      cat("Promotion times coefficients:\n")
      stats::printCoefmat(x$coefficients2, P.value=TRUE, has.Pvalue=TRUE)
    }
  }else{
    cat("Call:\n")
    print(x$call)
    cat("\n")
    cat("Cure fraction coefficients:\n")
    stats::printCoefmat(x$coefficients1, P.value=TRUE, has.Pvalue=TRUE)
    cat("\n")
    if(!is.null(x$coefficients2)){
      cat("Promotion times short-term coefficients:\n")
      stats::printCoefmat(x$coefficients2, P.value=TRUE, has.Pvalue=TRUE)
      cat("\n")
      cat("Promotion times long-term coefficients:\n")
      stats::printCoefmat(x$coefficients3, P.value=TRUE, has.Pvalue=TRUE)
    }
  }

  cat("\n")
  cat("--- \n")
  cat("loglik =", x$loglik, " ", "AIC =", x$AIC,"\n")
  cat("Algorithm convergence:", x$return_code == 0, "\n")
  if(x$vcov_check > 0){
    msg <- switch (x$vcov_check,
      "1" = "Attention: covariance matrix is semi positive definite!",
      "2" = "Attention: covariance matrix is neither positive or semi positive definite!"
    )
    message(msg)
    message("Please, try to fit the model again using another set of initial values")
  }




}


#---------------------------------------------

#' Summary for the survcure model
#'
#' @aliases summary.survcure
#' @export
#' @param object an objecto of the class 'survcure'.
#' @param ... further arguments passed to or from other methods.
#'
summary.survcure <- function(object, ...){
  p <- object$p
  q <- object$q

  n <- object$n
  k <- length(object$fit$par)

  loglik <- object$fit$value
  AIC <- -2*loglik + 2*k
  BIC <- -2*loglik + k*log(n)

  labels1 <- object$labels1
  labels2 <- object$labels2
  coeffs <- coef(object)
  V <- vcov(object)

  se <- sqrt(diag(V))
  zval <- coeffs / se
  TAB <- cbind(Estimate = coeffs,
               StdErr = se,
               z.value = zval,
               p.value = 2*stats::pnorm(-abs(zval)))

  if(object$reg < 3){
    if(q>0){
      TAB1 <- TAB[1:p, ,drop = FALSE]
      TAB2 <- TAB[(p+1):(p+q), ,drop = FALSE]
      rownames(TAB1) <- labels1
      rownames(TAB2) <- labels2

      res <- list(call=object$call,
                  coefficients1=TAB1, coefficients2=TAB2,
                  loglik=loglik, AIC=AIC)

    }else{
      rownames(TAB) <- labels1
      res <- list(call=object$call,
                  coefficients1=TAB,
                  coefficients2=NULL,
                  loglik=loglik, AIC=AIC)
    }
  }else{
    if(q>0){
      TAB1 <- TAB[1:p, , drop = FALSE]
      TAB2 <- TAB[(p+1):(p+q), , drop = FALSE]
      TAB3 <- TAB[(p+q+1):(p+2*q), , drop = FALSE]
      rownames(TAB1) <- labels1
      rownames(TAB2) <- labels2
      rownames(TAB3) <- labels2

      res <- list(call=object$call,
                  coefficients1=TAB1,
                  coefficients2=TAB2,
                  coefficients3=TAB3,
                  loglik=loglik, AIC=AIC)

    }else{
      rownames(TAB) <- labels1
      res <- list(call=object$call,
                  coefficients1=TAB,
                  coefficients2=NULL,
                  coefficients3=NULL,
                  loglik=loglik, AIC=AIC)
    }
  }

  res$reg <- object$reg
  res$return_code <- object$fit$return_code
  res$vcov_check <- check_vcov(object)
  class(res) <- "summary.survcure"
  return(res)
}
