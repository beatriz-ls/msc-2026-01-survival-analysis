
survcureSurvYP <- function(time, X1, X2, incidence, link, latency, survreg, par, tau, rho, m, p, q){
  y <- time/tau
  beta <- par[1:p]
  psi <- par[(p+1):(p+q)]
  phi <- par[(p+q+1):(p+2*q)]
  gamma <- par[(p+2*q+1):(p+2*q+m)]

  if(incidence == 3){
    nu <- par[length(par)]
  }

  if(latency == 1){
    H0 <- H0_weib(y, gamma)
  }else if(latency == 2){
    #ttt <- TTT(time, rho)/tau
    H0 <- YPPE:::Hpexp(time/tau, tgrid = rho/tau, rates = gamma)
    G <- matrix(0, ncol = 0, nrow  =  0)
  }else{
    k <- 1:m
    G <- matrix(stats::pbeta(y, k, m - k + 1), nrow=1)
    H0 <- as.numeric(G%*%gamma) + as.numeric(time>tau)*(time-tau)*m*gamma[m]/tau
    ttt <- matrix(0, ncol = 0, nrow  =  0)
  }

  lp_short = as.vector(X2%*%psi)
  lp_long = as.vector(X2%*%phi)
  Sz = surv_yp(H0, lp_short, lp_long)

  incidence <- list(
    count_dist = incidence,
    link = link
  )

  mu = invlinks(incidence, as.numeric(X1%*%beta))
  if(incidence[[1]] == 1){
    #Bernoulli
    Spop = Spop_bernoulli(Sz, mu)
  }else if(incidence[[1]] == 2){
    #Poisson
    Spop = Spop_poisson(Sz, mu)
  }else if(incidence[[1]] == 3){
    # negbin
    Spop = Spop_negbin(Sz, mu, nu)
  }else{
    #Bell
    #theta = LambertW::W(mu)
    Spop = Spop_bell(Sz, mu)
  }

  return(Spop)
}


survcureCrossSurv <- function(X11, X12, X21, X22, incidence, link, latency, survreg, par, tau0, tau, rho, m, p, q){
  diff_St <- function(time, X11, X12, X21, X22, incidence, link, latency, survreg, par, tau, rho, m, p, q){
    St1 <- survcureSurvYP(time=time, X1=X11, X2=X21,
                          incidence=incidence, link=link, latency=latency, survreg=survreg,
                          par=par, tau=tau, rho=rho, m=m, p=p, q=q)
    St2 <- survcureSurvYP(time=time, X1=X12, X2=X22,
                          incidence=incidence, link=link, latency=latency, survreg=survreg,
                          par=par, tau=tau, rho=rho, m=m, p=p, q=q)
    return(St1-St2)
  }
  I <- c(tau0, tau)
  t <- try(stats::uniroot(diff_St, interval=I, X11=X11, X12=X12, X21=X21, X22=X22,
                          incidence=incidence, link=link, latency=latency, survreg=survreg,
                          par=par, tau=tau, rho=rho, m=m, p=p, q=q)$root, TRUE)

  if(is(t, "try-error")){
    return(NA)
  }else{
    return(t)
  }
  return(t)
}





#---------------------------------------------
#' Generic S3 method cross_time
#' @aliases cross_time
#' @export
#' @param object a fitted model object
#' @param ... further arguments passed to or from other methods.
#' @return the crossing survival time
#'
cross_time <- function(object, ...) UseMethod("cross_time")


#' Computes the crossing survival times
#'
#' @aliases cross_time.survcure
#' @description Computes the crossing survival times along with their corresponding confidence/credible intervals.
#' @rdname cross_time-methods
#' @method cross_time survcure
#' @export
#' @export cross_time
#' @param object an object of class survcure
#' @param newdata1 a data frame containing the first set of explanatory variables
#' @param newdata2 a data frame containing the second set of explanatory variables
#' @param conf.level level of the confidence/credible intervals; default is conf.level = 0.95
#' @param nboot number of bootstrap samples (default nboot=4000); ignored if approach="bayes".
#' @param ... further arguments passed to or from other methods.
#' @return  the crossing survival time

cross_time.survcure <- function(object, newdata1, newdata2,
                                conf.level=0.95, nboot=1000, ...){
  q <-object$q
  p <-object$p
  m <- object$m
  mf <- object$mf
  labels <- names(mf)[-1]
  latency <- object$latency
  formula <- stats::update(object$formula, Surv(time, status) ~ .)
  mf <- object$mf
  resp <- stats::model.response(mf)
  time <- stats::model.response(mf)[,1]
  status <- resp[,2]
  data <- data.frame(cbind(time, status, mf[,-1]))
  names(data) <- c("time", "status", labels)
  tau <- object$tau
  tau0 <- min(stats::model.response(mf)[,1])
  labels <- match.arg(names(newdata1), names(newdata2), several.ok=TRUE)
  labels <- match.arg(names(mf)[-1], names(newdata1), several.ok=TRUE)
  X11 <- model.matrix(formula, data = newdata1, rhs = 1)
  X12 <- model.matrix(formula, data = newdata2, rhs = 1)
  X21 <- suppressWarnings(try( as.matrix(stats::model.matrix(formula, data = newdata1, rhs = 2)[,-1]), TRUE))
  X22 <- suppressWarnings(try( as.matrix(stats::model.matrix(formula, data = newdata2, rhs = 2)[,-1]), TRUE))


  info <- object$model_info
  incidence <- info[1]
  link <- info[2]
  latency <- info[3]
  survreg <- info[4]

  if(latency == 2){
    rho <- object$rho
  }else{
    rho <- NULL
  }


  par <- survcure_boot(object, data, nboot)
  alpha <- 1 - conf.level
  prob <- c(alpha/2, 1-alpha/2)


  t <- c()
  ci <- matrix(nrow=nrow(newdata1), ncol=2)
  for(i in 1:nrow(newdata1)){
    t[i] <- survcureCrossSurv(X11[i,], X12[i,], X21[i,], X22[i,],
                              incidence, link, latency,
                              survreg, object$fit$par, tau0, tau, rho, m, p, q)
    aux <- apply(par, 1, survcureCrossSurv,
                 X11=X11[i,], X12=X12[i,], X21=X21[i,], X22=X22[i,],
                 incidence=incidence, link=link, latency=latency,
                 survreg=survreg, tau0=tau0, tau=tau, rho=rho,
                 m=m, p=p, q=q)
    ci[i,] <- stats::quantile(aux, probs=prob, na.rm=TRUE)
  }

  t <- data.frame(cbind(t, ci))
  names(t) <- c("time", paste(100*prob, "%", sep=""))
  #names(t) <- c("time", "lwr", "upr")
  return(t)
}


