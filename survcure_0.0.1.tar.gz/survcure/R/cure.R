survcureCure <- function(X1, incidence, link, survreg, par, m, p, q){
  beta <- par[1:p]
  if(q>0){
    if(survreg == 3){
      psi <- par[(p+1):(p+q)]
      phi <- par[(p+q+1):(p+2*q)]
    }else{
      psi <- par[(p+1):(p+q)]
    }
  }

  if(incidence == 3){
    nu <- par[length(par)]
  }

  incidence <- list(
    count_dist = incidence,
    link = link
  )

  mu = invlinks(incidence, as.numeric(X1%*%beta))
  if(incidence[[1]] == 1){
    #Bernoulli
    pcure = stats::dbinom(0, size = 1, prob = mu)
  }else if(incidence[[1]] == 2){
    #Poisson
    pcure = stats::dpois(0, lambda = mu)
  }else if(incidence[[1]] == 3){
    # negbin
    pcure = (1+nu*mu)^(-1/nu)
  }else{
    #Bell
    theta = LambertW::W(mu)
    pcure = bellreg::dbell(0, theta)
  }

  return(pcure)
}



#---------------------------------------------
#' Probability of cure
#'
#' @aliases pcure
#' @description Computes the probability of cure for a given survcure model
#' @export
#' @param object an object of the class survcure
#' @param newdata a data frame containing the set of explanatory variables.
#' @param ... further arguments passed to or from other methods.
#' @return  the probability of cure.

pcure <- function(object, newdata, ...){
  mf <- object$mf
  labels <- names(mf)[-1]
  latency <- object$latency
  time <- sort( stats::model.response(mf)[,1])
  status <- sort( stats::model.response(mf)[,2])
  data <- data.frame(cbind(time, status, mf[,-1]))
  names(data) <- c("time", "status", names(mf)[-1])
  m <- object$m
  p <- object$p
  q <- object$q
  tau <- object$tau
  labels <- match.arg(names(newdata), labels, several.ok = TRUE)
  formula <- object$formula
  X1 <- model.matrix(formula, data = newdata, rhs = 1)
  X2 <- suppressWarnings(try( as.matrix(stats::model.matrix(formula, data = newdata, rhs = 2)[,-1]), TRUE))

  info <- object$model_info
  incidence <- info[1]
  link <- info[2]
  latency <- info[3]
  survreg <- info[4]

  par <- object$fit$par
  pcure <- survcureCure(X1, incidence, link, survreg, par, m, p, q)
  return(pcure)
}
