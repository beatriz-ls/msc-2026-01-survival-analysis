
is_unique <- function(x){
  return(length(unique(x))==1)
}

check_anova <- function(models){
  tab <- sapply(models, extract_model_info)
  res <- apply(tab, 1, is_unique)
  return(res)
}

num2incidence <- function(x){
  f <- function(x){
    incidence <- switch(x,
                     "1" = "Bernoulli",
                     "2" = "Poisson",
                     "3" = "negbin",
                     "4" = "Bell"
    )
    return(incidence)
  }
  incidence <- purrr::map_chr(x, f)
  return(unlist(incidence))

}

num2link <- function(incidence, link){
  f <- function(incidence, link){
    if(incidence == "Bernoulli"){
      link <- switch(link,
                     "1" = "logit",
                     "2" = "probit",
                     "3" = "cloglog")
    }else{
      link <- switch(link,
                     "1" = "log",
                     "2" = "identity",
                     "3" = "sqrt")
    }
    return(link)
  }
  link <- purrr::map2_chr(incidence, link, f)
  return(unlist(link))

}


num2survreg <- function(x){
  f <- function(y){
    res <- switch(y+1,
                  "0" = "none",
                  "1" = "ph",
                  "2" = "po",
                  "3" = "yp")
    return(res)
  }
  res <- purrr::map_chr(x, f)
  return(unlist(res))
}


num2latency <- function(x){
  f <- function(y){
    res <- switch(y,
                  "1" = "Weibull",
                  "2" = "pe",
                  "3" = "bp")
    return(res)
  }
  res <- purrr::map_chr(x, f)
  return(unlist(res))
}


extract_model_info <- function(object){
  return(object$model_info)
}

extract_formulas <- function(object){
  return(object$formula)
}


#---------------------------------------------
#' anova method for survcure models
#'
#' @aliases anova.survcure
#' @description Compute analysis of variance (or deviance) tables for one or more fitted model objects.
#' @importFrom stats anova
#' @export
#' @param ... further arguments passed to or from other methods.
#' @return  the ANOVA table.
#'
anova.survcure <- function(...){
  models <- c(as.list(environment()), list(...))

  nested <- check_anova(models)
  if(nested[1] == FALSE | nested[2] == FALSE | nested[3] == FALSE){
    warning("Sorry... only nested models are allowed!")
  }else{
    J <- nargs()
    labels <- paste0("Model ", 1:J, ":")
    k <- c()
    df <- c()
    k[J] <- length(models[[J]]$fit$par)
    LR <- c()
    p.value <- c()
    loglik <- c()
    loglik[J] <- models[[J]]$fit$value
    for(j in 1:(J-1)){
      loglik[j] <- models[[j]]$fit$value
      LR[j] <- 2*(models[[J]]$fit$value - models[[j]]$fit$value)
      k[j] <- length(models[[j]]$fit$par)
      df[j] <- k[J]-k[j]
      p.value[j] <- stats::pchisq(LR[j], df = df[j], lower.tail = FALSE)
    }

    info <- sapply(models, extract_model_info)
    # latency <- switch(nested
    #
    # )

    tab <- cbind("loglik" = loglik[-J], LR, df, 'Pr(>Chi)' = p.value)
    aux <- matrix(c(loglik[J], NA, NA, NA), nrow = 1)
    tab <- rbind(tab, aux)
    #tab <- cbind(survreg, tab)
    rownames(tab) <- labels
    formulas <- sapply(models, extract_formulas)

    incidence <- switch(models[[1]]$incidence$count_dist,
                     "1" = "Bernoulli",
                     "2" = "Poisson",
                     "3" = "negbin",
                     "4" = "Bell")

    if(models[[1]]$incidence$count_dist == "Bernoulli"){
      link <- switch(models[[1]]$incidence$link,
                     "1" = "logit",
                     "2" = "probit",
                     "3" = "cloglog")
    }else{
      link <- switch(models[[1]]$incidence$link,
                     "1" = "log",
                     "2" = "identity",
                     "3" = "sqrt")
    }

    latency <- num2latency(info[3,1])
    survreg <- num2survreg(info[4,])

    cat("\n")
    cat("incidence:", incidence, "\n")
    cat("Link function:",  link, "\n")
    cat("latency baseline distribution:", latency, "\n")
    cat("--- \n")
    cat("\n")
    for(j in 1:J){
      cat("Model", j, "(", survreg[j], "): ", deparse(formulas[[j]]), "\n")
    }
    cat("\n")
    cat("--- \n")
    stats::printCoefmat(tab, P.values=TRUE, has.Pvalue = TRUE, na.print = "-")
  }

}
