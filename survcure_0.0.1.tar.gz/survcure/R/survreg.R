
#------------------------------------------------------------------------------
# PH model

surv_ph <- function(H0,  lp){
  surv <- exp(- H0* exp(lp))
  return(surv)
}


#------------------------------------------------------------------------------
  # P0 model

surv_po <- function(H0, lp){
  Rt = expm1(H0) * exp(lp)
  surv = 1 / (1 + Rt)
  return(surv);
}


#------------------------------------------------------------------------------
  # YP model

surv_yp <- function(H0,  lp_short, lp_long){
  R0 = expm1(H0)
  ratio = exp(lp_short - lp_long)
  yp <- exp( -exp(lp_long)*log1p(ratio*R0) )
  #yp <- (1 + ratio*R0 )^(-exp(lp_long));
  # for(i in 1:n){
  #   yp[i] = (1 + ratio[i]*R0[i] )^(-exp(lp_long[i]))
  # }
  return(yp)
}

