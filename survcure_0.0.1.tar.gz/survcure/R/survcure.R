
#' Fitting cure rate survival models
#' @aliases survcure
#' @export
#' @param formula n object of class "formula" (or one that can be coerced to that class): a symbolic description of the model to be fitted.
#' @param data an optional data frame, list or environment (or object coercible by as.data.frame to a data frame) containing the variables in the model. If not found in data, the variables are taken from environment(formula), typically the environment from which survcure is called.
#' @param incidence the distribution assumed for the (latent) count variable in the promotion time cure rate model.
#' @param latency the latency distribution assumed to model the (latent) promotion times; currently available models: Weibull, piecewise exponential (PE) distribution, and Bernstein polynomials.
#' @param m either the number of intervals associated with the time grid of the PE distribution or the degree of the Bernstein polynomials. Default is NULL (see details).
#' @param rho the time grid of the PE distribution. If NULL, the function timeGrid is used to compute rho.
#' @param hessian logical; If TRUE (default), the hessian matrix is returned when approach="mle".
#' @param init initial values specification (default value is 0); see the detailed documentation for \code{init} in \code{\link[rstan]{optimizing}}.
#' @param ... further arguments passed to other methods.
#'
#'
survcure <- function(formula, data,
                  incidence = c("bernoulli", "poisson", "bell", "negbin"),
                  latency = c("weibull", "pe", "bp") ,
                  m = NULL, rho = NULL, hessian = TRUE, init = 0, ...){
  # model_info <- list(incidence = extract_incidence(incidence), latency = extract_latency(latency))
  # names(model_info) <- c("incidence", "link", "latency", "survreg")
  model_info <- c(incidence = extract_incidence(incidence), latency = extract_latency(latency))
  names(model_info) <- c("incidence", "link", "latency", "survreg")
  incidence <- extract_incidence(incidence)
  latency <- extract_latency(latency)
  formula <- Formula::Formula(formula)
  mf <- stats::model.frame(formula=formula, data=data)
  Terms <- stats::terms(mf)
  resp <- stats::model.response(mf)
  time <- resp[,1]
  status <- resp[,2]
  X1 <- stats::model.matrix(formula, data = mf, rhs = 1)
  X2 <- suppressWarnings(try( stats::model.matrix(formula, data = mf, rhs = 2)[,-1, drop = FALSE], TRUE))
  labels1 <- colnames(X1)
  labels2 <- colnames(X2)
  n <- nrow(X1)
  X1 <- matrix(X1, ncol=length(labels1))
  if(ncol(X2) > 0){
    n2 <- n
    q <- ncol(X2)
  }else{
    X2 <- array(0, dim = c(0, 0))
    n2 <- 0
    q <- 0
  }

  n <- length(time)
  p <- ncol(X1)
  tau <- max(time)
  #time <- time/tau

  if(latency$latency == 1){
    m <- 2
    rho <- vector(length = 0)
    ttt <- matrix(0, ncol = 0, nrow  =  0)
    idt <- vector(length = 0)
    g <- matrix(0, ncol = 0, nrow  =  0)
    G <- matrix(0, ncol = 0, nrow  =  0)
  }else if(latency$latency == 2){
    if(is.null(rho) & is.null(m)){
      m <- min(c(25, ceiling(n^0.4)))
      rho <- peppm::timeGrid(time, status, n.int = m)
    }else if(!is.null(m) & is.null(rho)){
      rho <- peppm::timeGrid(time, status, n.int = m)
    }else{
      m <- length(rho) - 1
    }

    idt <- as.numeric(cut(time, rho, include.lowest = TRUE))
    ttt <- TTT(time, rho)
    rho <- rho/tau
    ttt <- ttt/tau
    g <- matrix(0, ncol = 0, nrow  =  0)
    G <- matrix(0, ncol = 0, nrow  =  0)
  }else{
    if(is.null(m)){
      #m <- ceiling(sqrt(n))
      m <- ceiling(n^0.4)
    }
    rho <- vector(length = 0)
    idt <- vector(length = 0)
    ttt <- matrix(0, ncol = 0, nrow  =  0)
    bases  <- bp_bases(time, degree = m, tau)
    g <- bases$b
    G <- bases$B
  }


  is_negbin <- ifelse(incidence$count_dist == 3, 1, 0)
  stan_data <- list(time=time, status=status, n=n, p=p, q=q, m=m, X1=X1,
                    X2=X2, tau=tau, count_dist=incidence$count_dist,
                    link = incidence$link, promo_dist = latency$latency,
                    is_negbin = is_negbin, reg_incidence = latency$survreg,
                    rho = rho, idt = idt, ttt = ttt, g = g, G = G)

  fit <- rstan::optimizing(stanmodels$survcure, data = stan_data,
                           hessian = hessian, init = init, ...)
  if(hessian == TRUE){
    # fit$hessian <- - fit$hessian
    fit$hessian <- as.matrix(Matrix::nearPD(-fit$hessian)$mat) # 2026-02-20
  }
  output <- list(fit=fit)
  output$incidence <- incidence
  output$latency <- latency$latency
  output$reg <- latency$survreg

  if(q == 0){
    model_info[4] <- 0
  }

  output$n <- n
  output$q <- q
  output$p <- p
  output$m <- m
  if(latency$latency == 2){
    output$rho <- rho*tau
  }

  if(latency$latency == 3){
    output$g <- g
    output$G <- G
  }
  output$tau <- tau
  output$call <- match.call()
  output$formula <- formula
  output$terms <- stats::terms.formula(formula)
  output$mf <- mf
  output$labels1 <- labels1
  output$labels2 <- labels2
  output$model_info <- unlist(model_info)
  output$npar = length(fit$par)
  class(output) <- "survcure"

  return(output)

}




#---------------------------------------------

survcure_boot <- function(object, data, nboot = 1000, ...){
  formula <- Formula::Formula(object$formula)
  formula <- stats::update(formula, Surv(time, status) ~ .)
  mf <- object$mf
  resp <- stats::model.response(mf)
  time <- stats::model.response(mf)[,1]
  status <- resp[,2]
  data <- data.frame(cbind(time, status, mf[,-1]))
  n <- length(status)
  m <- object$m

  index <- 1:n
  index1 <- which(status==1)
  index2 <- which(status==0)
  n1 <- length(index1)
  n2 <- length(index2)
  par <- matrix(nrow=nboot, ncol=object$npar)

  incidence <- switch (object$incidence$count_dist,
      "1" = "bernoulli",
      "2" = "poisson",
      "3" = "negbin",
      "4" = "bell"
    )

  link <- if(incidence == "bernoulli"){
    switch(object$incidence$link,
      "1" = "logit",
      "2" = "probit",
      "3" = "cloglog"
    )
  }else{
    switch(object$incidence$link,
      "1" = "log",
      "2" = "identity",
      "3" = "sqrt"
    )
  }

  latency <- switch (object$latency,
    "1" = "weibull",
    "2" = "pe",
    "3" = "bp"
  )

  tau <- object$tau
  if(object$latency == 2){
    rho <- object$rho
  }else{
    rho <- "NULL"
  }


  pb <- progress::progress_bar$new(total = nboot)

  for(step in 1:nboot){
    pb$tick()
    Sys.sleep(1 / nboot)
    samp1 <- sample(index1, size=n1, replace=TRUE)
    samp2 <- sample(index2, size=n2, replace=TRUE)
    samp <- c(samp1, samp2)
    suppressWarnings({invisible(utils::capture.output(
      fit_boot <- survcure(formula, data=data[samp,],
                         incidence = switch (incidence,
                                          "bernoulli" = bernoulli(link),
                                          "poisson" = poisson(link),
                                          "negbin" = negbin(link),
                                          "bell" = bell(link)
                         ),
                         latency = switch(latency,
                                           "weibull" = weibull("yp"),
                                           "pe" = pe("yp"),
                                           "bp" = bp("yp")
                         ),
                         m=m, hessian=FALSE, init=0)))})
    if(is(fit_boot, "try-error")){
      step <- step + 1
    }else{
      par[step, ] <- fit_boot$fit$par
      step <- step + 1
    }


  }

  colnames(par) <- names(fit_boot$fit$par[-grep("log_", names(fit_boot$fit$par))])

  return(par)
}
