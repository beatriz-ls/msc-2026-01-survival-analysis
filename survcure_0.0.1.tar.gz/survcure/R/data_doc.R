#' E1673 Melanoma Clinical Trial.
#'
#' @name e1673
#' @docType data
#' @author Fabio N. Demarqui \email{fndemarqui@est.ufmg.br}
#' @keywords datasets
#' @description E1673 clinical trial data corresponding to a melanoma study conducted by the Eastern Cooperative Oncology Group (ECOG). This data set is reported in \insertCite{2001Ibrahim}{survcure}, and involves n = 650 patients who were followed up for over 20 years.
#' @format A data frame with 650 rows and 5 variables:
#' \itemize{
#'   \item time: survival time  (in years)
#'   \item status: failure indicator (1 - failure; 0 - otherwise)
#'   \item age: patient's age
#'   \item gender: patient's gender (0 - male; 1 - female)
#'   \item ps: patient's performance status (0 - fully active; 1 - other)
#' }
#' @references
#'
#' \insertRef{2001Ibrahim}{survcure}
#'
NULL




#' E1684 Melanoma Clinical Trial.
#'
#' @name e1684
#' @docType data
#' @author Fabio N. Demarqui \email{fndemarqui@est.ufmg.br}
#' @keywords datasets
#' @description Two-arm phase III clinical trial conducted by the Eastern Cooperative Oncology Group (ECOG) to comparing high-dose interferon (IFN) to observation (OBS). There were a total of 286 patients diagnosed with melanoma enrolled in the study, which accrued from 1984 to 1990, and the study was unblinded in 1993.
#' @format A data frame with 286 rows and 10 variables:
#' \itemize{
#'   \item trt: treatment (0 - observation, 1 - IFN)
#'   \item failtime: time to relapse from randomization
#'   \item failcens: failure indicator (1 - failure; 0 - otherwise)
#'   \item survtime: time from relapse to death
#'   \item survcens: failure indicator (1 - failure; 0 - otherwise)
#'   \item age: patient's age (in years)
#'   \item node: 4 nodal categories
#'   \item sex: patient's (0=male, 1=female)
#'   \item ps: patient's performance status (0 - fully active; 1 - other)
#'   \item breslow: Breslow depth (in mm)
#' }
#' @references
#'
#' \insertRef{2001Ibrahim}{survcure}
#'
NULL

#' E1690 Melanoma Clinical Trial.
#'
#' @name e1690
#' @docType data
#' @author Fabio N. Demarqui \email{fndemarqui@est.ufmg.br}
#' @keywords datasets
#' @description The ECOG trial E1690 was a three-arm phase III clinical trial and had treatment arms consisting of high-dose interferon, low-dose interferon, and observation. This study, conducted by the Eastern Cooperative Oncology Group (ECOG), had n = 427 patients on the high-dose interferon arm and observation arm combined. E1690 was initiated right after the completion of E1684, and accrued patients from 1991 until 1995, and was unblinded in 1998.
#' @format A data frame with 427 rows and 10 variables:
#' \itemize{
#'   \item trt: treatment (0 - observation, 1 - IFN)
#'   \item failtime: time to relapse from randomization
#'   \item failcens: failure indicator (1 - failure; 0 - otherwise)
#'   \item survtime: time from relapse to death
#'   \item survcens: failure indicator (1 - failure; 0 - otherwise)
#'   \item age: patient's age (in years)
#'   \item node: 4 nodal categories
#'   \item sex: patient's (0=male, 1=female)
#'   \item ps: patient's performance status (0 - fully active; 1 - other)
#'   \item breslow: Breslow depth (in mm)
#' }
#' @references
#'
#' \insertRef{2001Ibrahim}{survcure}
#'
NULL
