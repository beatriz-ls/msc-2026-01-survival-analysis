

invAp <- function(u, incidence, mu, nu = NULL){
  if(incidence[[1]] == "4"){
    theta <- LambertW::W(mu)
  }
  inv <- switch (incidence[[1]],
                 "1" = (u - 1 + mu)/mu,
                 "2" = (log(u) + mu)/mu,
                 "3" = 1 - (u^(-nu) - 1)/(nu*mu),
                 "4" = log(log(u) + exp(theta))/theta
  )
  return(inv)
}



invHaz <- function(r, lambda, kappa, gamma, incidence){
  incidence <- match.arg(incidence)
  inv <- switch (incidence,
                 weibull = (r/gamma[2])^(1/gamma[1]) #gamma[1]: shape; gamma[2]: rate
  )
  return(inv)
}


rYP <- function(u, Z, psi, phi, gamma, latency){
  # psi = phi: PH
  # phi = 0: PO
  # psi != phi: YP
  ratio <- as.numeric(exp(Z%*%(phi-psi)))
  kappa <- exp(Z%*%phi)
  w <- as.numeric((u^(-1/kappa) - 1)*ratio)
  r <- log(1+w)
  time <- switch (latency,
                  "weibull" = (r/gamma[2])^(1/gamma[1])  # Weibull (JAGS parametrization)
  )
  return(time)
}

probCure <- function(incidence, mu, nu = NULL){
  prob <- switch (incidence[[1]],
    "1" = 1-mu,
    "2" = exp(-mu),
    "3" = (1+nu*mu)^(-1/nu),
    "4" = exp(-exp(LambertW::W(mu))+1)
  )
  return(prob)
}

#' Random generation of survival data with cure fraction
#' @export
#' @aliases rsurvcure
#' @description Function to generate a random sample of survival data with cure fraction.
#' @param formula formula specifying the linear predictors
#' @param covariates data frame containing the covariates used to generate the survival times
#' @param incidence incidence distribution assigned to N
#' @param latency latency model
#' @param gamma latency parameters
#' @param beta cure regression coefficients
#' @param psi short-term regression coefficients
#' @param phi long-term regression coefficients
#' @param nu extra negative-binomial parameter
#' @param max_fu maximum follow-up time
#' @param ... further arguments passed to other methods.
#'

rsurvcure <- function(formula, covariates,
                      incidence = c("bernoulli", "poisson", "negbin",  "bell"),
                      latency = "weibull",
                      gamma, beta, psi = NULL, phi = NULL, nu = NULL, max_fu){
  incidence <- extract_incidence(incidence)
  latency <- extract_latency(latency)
  formula <- Formula::Formula(formula)
  mf <- stats::model.frame(formula=formula, data=covariates)
  X1 <- stats::model.matrix(formula, data = mf, rhs = 1)
  X2 <- suppressWarnings(try( stats::model.matrix(formula, data = mf, rhs = 2)[,-1, drop = FALSE], TRUE))
  n <- nrow(X1)
  u <- runif(n)
  mu <- invlinks(incidence, as.numeric(X1%*%beta))
  q <- ncol(X2)
  cure <- probCure(incidence, mu = mu, nu = nu)
  is_cured <- u <= cure
  t <- c()
  time <- c()
  status <- c()
  c <- runif(n, 0, max_fu)
  for(i in 1:n){
    if(isTRUE(is_cured[i])){
      t[i] <- Inf
      status[i] <- 0
    }else{
      v <- invAp(u[i], incidence = incidence, mu = mu[i], nu = nu)
      if(q>0){
        t[i] <- rYP(u = v, Z = X2[i,], psi = psi, phi = phi, gamma = gamma, latency = latency[[1]])
      }else{
        t[i] <- rYP(u = v, Z = X2[i,], psi = rep(0, q), phi = rep(0, q), gamma = gamma, latency = latency[[1]])
      }

    }
    time[i] <- min(t[i], c[i])
    status[i] <- as.numeric(t[i] < c[i])
  }
  data <- data.frame(time = time,
                     status = status,
                     cured = as.numeric(is_cured))
  data <- dplyr::bind_cols(data, mf)

  if(q == 0){
    real <- c(beta=beta, gamma=gamma)
  }else{
    real <- c(beta=beta, psi=psi, phi=phi, gamma=gamma)
  }

  if(incidence$count_dist == 3){
    real <- c(real, nu=nu)
  }

  data.table::setattr(data, "incidence", incidence)
  data.table::setattr(data, "latency", latency)
  data.table::setattr(data, "formula", formula)
  data.table::setattr(data, "pars", real)

  return(data)
}

