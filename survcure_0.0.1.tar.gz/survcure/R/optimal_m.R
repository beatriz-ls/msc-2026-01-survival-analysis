#
#
# optimal_m <- function(formula, data,
#                       incidence = c("bernoulli", "poisson", "bell", "negbin"),
#                       latency = c("pe", "bp"), M = NULL){
#
#   M <- ifelse(is.null(M), 20, M)
#   tb <- matrix(nrow = M, ncol = 7)
#
#   for(m in 1:M){
#     fit <- survcure(formula = formula, data = data,
#                     incidence = incidence, latency = latency,
#                     init = 0, m = m, hessian = FALSE)
#     tb[m, ] <- c(m, AIC(fit), fit$model_info, fit$fit$return_code)
#   }
#
#   colnames(tb) <- c("m", "AIC", "incidence", "link", "latency", "survreg", "convergence")
#   tb <- as.data.frame(tb)
#   tb <- tb %>%
#     dplyr::mutate(
#       incidence = num2incidence(incidence),
#       link = num2link(incidence, link),
#       latency = num2latency(latency),
#       survreg = num2survreg(survreg),
#       convergence = ifelse(convergence == 0, TRUE, FALSE)
#     )
#   return(tb)
#
# }
#
#
#
# best_fits <- function(formula, data,
#                       families = c("bernoulli", "poisson", "bell", "negbin"),
#                       latencys = c("pe", "bp"), survregs = c("ph", "po", "yp"), M = NULL){
#
#   M <- ifelse(is.null(M), 20, M)
#
#
#   tb <- data.frame()
#   for(incidence in families){
#     for(latency in latencys){
#       for(survreg in survregs){
#         if(latency == "pe"){
#           df <- suppressWarnings(
#             try(
#               switch (survreg,
#                       "ph" = optimal_m(formula, incidence = incidence, latency = pe("ph"), data = data, M = M),
#                       "po" = optimal_m(formula, incidence = incidence, latency = pe("po"), data = data, M = M),
#                       "yp" = optimal_m(formula, incidence = incidence, latency = pe("yp"), data = data, M = M),
#               ), TRUE
#             )
#           )
#         }else{
#           df <- suppressWarnings(
#             try(
#               switch (survreg,
#                       "ph" = optimal_m(formula, incidence = incidence, latency = bp("ph"), data = data, M = M),
#                       "po" = optimal_m(formula, incidence = incidence, latency = bp("po"), data = data, M = M),
#                       "yp" = optimal_m(formula, incidence = incidence, latency = bp("yp"), data = data, M = M),
#               ), TRUE
#             )
#           )
#         }
#         tb <- dplyr::bind_rows(tb, df)
#       }
#     }
#   }
#   return(tb)
# }
