

survcureSurv <- function(time, X1, X2, incidence, link, latency, survreg, par, tau, m, p, q, ttt, G){
  y <- time/tau
  beta <- par[grep("beta", names(par))]
  gamma <- par[grep("gamma", names(par))]
  if(survreg %in% 1:2){
    psi <- par[grep("psi", names(par))]
  }else if(survreg == 3){
    psi <- par[grep("psi", names(par))]
    phi <- par[grep("phi", names(par))]
  }

  if(incidence == 3){
    nu <- par[length(par)]
  }

  if(latency == 1){
    H0 <- H0_weib(y, gamma)
  }else if(latency == 2){
    # rho <- object$rho
    # ttt <- TTT(time, rho)/tau
    H0 <- H0_pe(ttt, gamma)
  }else{
    # G <- object$G
    H0 <- H0_bp(G, gamma)
  }


  if(q == 0){
    Sz <- exp(-H0)
  }else{
    if(survreg == 1){
      lp2 = as.vector(X2%*%psi)
      Sz <- surv_ph(H0, lp2)
    }else if(survreg == 2){
      lp2 = as.vector(X2%*%psi)
      Sz = surv_po(H0, lp2)
    }else{
      lp_short = as.vector(X2%*%psi)
      lp_long = as.vector(X2%*%phi)
      Sz = surv_yp(H0, lp_short, lp_long)
    }
  }

  incidence <- list(
    count_dist = incidence,
    link = link
  )

  mu = invlinks(incidence, as.numeric(X1%*%beta))
  if(incidence[[1]] == 1){
    #Bernoulli
    Spop = Spop_bernoulli(Sz, mu)
  }else if(incidence[[1]] == 2){
    #Poisson
    Spop = Spop_poisson(Sz, mu)
  }else if(incidence[[1]] == 3){
    # negbin
    Spop = Spop_negbin(Sz, mu, nu)
  }else{
    #Bell
    #theta = LambertW::W(mu)
    Spop = Spop_bell(Sz, mu)
  }

  return(Spop)
}



#---------------------------------------------
#' survfit method for survcure models
#'
#' @aliases survfit.survcure
#' @description Computes the predicted survivor function for a ypbp model.
#' @importFrom survival survfit
#' @export
#' @param formula an object of the class ypbp
#' @param newdata a data frame containing the set of explanatory variables.
#' @param ... further arguments passed to or from other methods.
#' @return  a list containing the estimated survival probabilities.
#'
survfit.survcure <- function(formula, newdata, ...){
  object <- formula
  mf <- object$mf
  labels <- names(mf)[-1]
  latency <- object$latency
  time <- sort( stats::model.response(mf)[,1])
  status <- sort( stats::model.response(mf)[,2])
  data <- data.frame(cbind(time, status, mf[,-1]))
  names(data) <- c("time", "status", names(mf)[-1])
  m <- object$m
  p <- object$p
  q <- object$q
  tau <- object$tau
  labels <- match.arg(names(newdata), labels, several.ok = TRUE)
  formula <- object$formula
  X1 <- stats::model.matrix(formula, data = newdata, rhs = 1)
  X2 <- suppressWarnings(try( as.matrix(stats::model.matrix(formula, data = newdata, rhs = 2)[,-1]), TRUE))
  St <- list()

  info <- object$model_info
  incidence <- info[1]
  link <- info[2]
  latency <- info[3]
  survreg <- info[4]

  # teste para compatibilidade com ggsurv
  # time <- time[status == 1]

  if(latency == 2){
    rho <- object$rho
    ttt <- TTT(time, rho)/tau
    G <- matrix(0, ncol = 0, nrow  =  0)
  }else if(latency == 3){
    G <- bp_bases(time, degree = m, tau)$B
    ttt <- matrix(0, ncol = 0, nrow  =  0)
  }

  par <- object$fit$par
  for(i in 1:nrow(newdata)){
    St[[i]] <- survcureSurv(time, X1[i,], X2[i,], incidence, link, latency, survreg, par, tau, m, p, q, ttt, G)
  }



  out <- list(time = time, surv = St)
  class(out) <- "survfit.survcure"
  return(out)
}


