



# *****************************************************************
# Bernstein Polynomials:

H0_bp <- function(G, gamma){
  return( as.numeric(G%*%gamma))
}


# *****************************************************************
# Piecewise Exponential (PE) distribution:


H0_pe <- function(ttt, gamma){
  return( as.numeric(ttt%*%gamma) );
}



# *****************************************************************
# Weibull (Weib) distribution:



H0_weib <- function(y, gamma){
  # JAGS parametrization for the Weibull distribution
  # gamma[1]: shape parameter
  # gamma[2]: scale parameter
  return( gamma[2] * exp(gamma[1]*log(y)) );
}


